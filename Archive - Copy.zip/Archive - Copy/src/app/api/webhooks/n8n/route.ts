import { NextRequest, NextResponse } from 'next/server';
import log from '@/lib/logger';
import workflowService from '@/services/workflow.service';
import type { N8nWebhookPayload } from '@/types';

const N8N_API_KEY = process.env.N8N_API_KEY || '';

/**
 * POST - Receive workflow updates from n8n
 */
export async function POST(request: NextRequest) {
  try {
    // Verify API key
    const apiKey = request.headers.get('x-api-key');
    if (N8N_API_KEY && apiKey !== N8N_API_KEY) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body: N8nWebhookPayload = await request.json();

    log.workflow('n8n webhook received', {
      workflowInstanceId: body.workflowInstanceId,
      status: body.status,
    });

    // Update workflow status
    await workflowService.updateStatus(
      body.workflowInstanceId,
      body.status === 'completed' ? 'COMPLETED' : 'FAILED',
      {
        currentStep: body.step,
        context: body.data,
        errorMessage: body.error,
      }
    );

    return NextResponse.json({ success: true });

  } catch (error) {
    log.error('n8n webhook error', { error });
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
