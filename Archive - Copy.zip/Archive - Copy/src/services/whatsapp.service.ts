import axios, { AxiosInstance } from 'axios';
import log from '@/lib/logger';

const WA_API_VERSION = process.env.WA_API_VERSION || 'v18.0';
const WA_API_URL = `https://graph.facebook.com/${WA_API_VERSION}`;

class WhatsAppService {
  private api: AxiosInstance;
  private phoneNumberId: string;

  constructor() {
    this.phoneNumberId = process.env.WA_PHONE_NUMBER_ID || '';
    
    this.api = axios.create({
      baseURL: WA_API_URL,
      headers: {
        'Authorization': `Bearer ${process.env.WA_ACCESS_TOKEN}`,
        'Content-Type': 'application/json',
      },
    });
  }

  /**
   * Send text message
   */
  async sendText(to: string, text: string): Promise<string | null> {
    try {
      const response = await this.api.post(`/${this.phoneNumberId}/messages`, {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'text',
        text: {
          preview_url: true,
          body: text,
        },
      });

      const messageId = response.data?.messages?.[0]?.id;
      log.whatsapp('Text message sent', { to, messageId });
      return messageId;
    } catch (error: any) {
      log.error('WhatsApp send text error', { 
        to, 
        error: error.response?.data || error.message 
      });
      throw error;
    }
  }

  /**
   * Send template message (for marketing/utility outside 24h window)
   */
  async sendTemplate(
    to: string,
    templateName: string,
    languageCode = 'id',
    components: any[] = []
  ): Promise<string | null> {
    try {
      const response = await this.api.post(`/${this.phoneNumberId}/messages`, {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'template',
        template: {
          name: templateName,
          language: { code: languageCode },
          components,
        },
      });

      const messageId = response.data?.messages?.[0]?.id;
      log.whatsapp('Template message sent', { to, template: templateName, messageId });
      return messageId;
    } catch (error: any) {
      log.error('WhatsApp send template error', { 
        to, 
        template: templateName,
        error: error.response?.data || error.message 
      });
      throw error;
    }
  }

  /**
   * Send image
   */
  async sendImage(to: string, imageUrl: string, caption?: string): Promise<string | null> {
    try {
      const response = await this.api.post(`/${this.phoneNumberId}/messages`, {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'image',
        image: {
          link: imageUrl,
          caption,
        },
      });

      const messageId = response.data?.messages?.[0]?.id;
      log.whatsapp('Image sent', { to, messageId });
      return messageId;
    } catch (error: any) {
      log.error('WhatsApp send image error', { error: error.response?.data || error.message });
      throw error;
    }
  }

  /**
   * Send document
   */
  async sendDocument(
    to: string,
    documentUrl: string,
    filename: string,
    caption?: string
  ): Promise<string | null> {
    try {
      const response = await this.api.post(`/${this.phoneNumberId}/messages`, {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'document',
        document: {
          link: documentUrl,
          filename,
          caption,
        },
      });

      const messageId = response.data?.messages?.[0]?.id;
      log.whatsapp('Document sent', { to, filename, messageId });
      return messageId;
    } catch (error: any) {
      log.error('WhatsApp send document error', { error: error.response?.data || error.message });
      throw error;
    }
  }

  /**
   * Send interactive buttons
   */
  async sendButtons(
    to: string,
    bodyText: string,
    buttons: Array<{ id: string; title: string }>
  ): Promise<string | null> {
    try {
      const response = await this.api.post(`/${this.phoneNumberId}/messages`, {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'interactive',
        interactive: {
          type: 'button',
          body: { text: bodyText },
          action: {
            buttons: buttons.slice(0, 3).map((btn) => ({
              type: 'reply',
              reply: {
                id: btn.id,
                title: btn.title.substring(0, 20),
              },
            })),
          },
        },
      });

      const messageId = response.data?.messages?.[0]?.id;
      log.whatsapp('Buttons sent', { to, messageId });
      return messageId;
    } catch (error: any) {
      log.error('WhatsApp send buttons error', { error: error.response?.data || error.message });
      throw error;
    }
  }

  /**
   * Send list menu
   */
  async sendList(
    to: string,
    headerText: string,
    bodyText: string,
    buttonText: string,
    sections: Array<{
      title: string;
      rows: Array<{ id: string; title: string; description?: string }>;
    }>
  ): Promise<string | null> {
    try {
      const response = await this.api.post(`/${this.phoneNumberId}/messages`, {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'interactive',
        interactive: {
          type: 'list',
          header: { type: 'text', text: headerText },
          body: { text: bodyText },
          action: {
            button: buttonText,
            sections,
          },
        },
      });

      const messageId = response.data?.messages?.[0]?.id;
      log.whatsapp('List sent', { to, messageId });
      return messageId;
    } catch (error: any) {
      log.error('WhatsApp send list error', { error: error.response?.data || error.message });
      throw error;
    }
  }

  /**
   * Mark message as read
   */
  async markAsRead(messageId: string): Promise<boolean> {
    try {
      await this.api.post(`/${this.phoneNumberId}/messages`, {
        messaging_product: 'whatsapp',
        status: 'read',
        message_id: messageId,
      });
      return true;
    } catch (error: any) {
      log.error('WhatsApp mark as read error', { error: error.response?.data || error.message });
      return false;
    }
  }

  /**
   * Download media file
   */
  async downloadMedia(mediaId: string): Promise<{ buffer: Buffer; mimeType: string } | null> {
    try {
      // Get media URL
      const mediaResponse = await this.api.get(`/${mediaId}`);
      const mediaUrl = mediaResponse.data.url;

      // Download the file
      const fileResponse = await axios.get(mediaUrl, {
        headers: {
          'Authorization': `Bearer ${process.env.WA_ACCESS_TOKEN}`,
        },
        responseType: 'arraybuffer',
      });

      return {
        buffer: Buffer.from(fileResponse.data),
        mimeType: mediaResponse.data.mime_type,
      };
    } catch (error: any) {
      log.error('WhatsApp download media error', { error: error.response?.data || error.message });
      return null;
    }
  }
}

export const whatsappService = new WhatsAppService();
export default whatsappService;
