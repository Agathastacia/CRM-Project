import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

/**
 * POST /api/conversations/[conversationId]/messages
 * Body: { content: "Pesan dari agent" }
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { conversationId: string } }
) {
  try {
    // Validasi conversationId
    const conversationId = params.conversationId
    
    if (!conversationId) {
      return NextResponse.json(
        { error: 'Conversation ID is required' },
        { status: 400 }
      )
    }

    const { content } = await request.json()
    
    if (!content || typeof content !== 'string') {
      return NextResponse.json(
        { error: 'Message content is required' },
        { status: 400 }
      )
    }

    // Cek conversation exists
    const conversation = await prisma.conversation.findUnique({
      where: { id: conversationId },
      include: { customer: true }
    })

    if (!conversation) {
      return NextResponse.json(
        { error: 'Conversation not found' },
        { status: 404 }
      )
    }

    // Simpan message baru
    const message = await prisma.message.create({
      data: {
        conversationId: conversationId,
        senderType: 'AGENT',
        content: content,
        contentType: 'TEXT'
      }
    })

    // Update conversation
    await prisma.conversation.update({
      where: { id: conversationId },
      data: {
        status: 'WAITING_CUSTOMER',
        lastMessageAt: new Date()
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Message sent successfully',
      data: message
    })

  } catch (error: any) {
    console.error('❌ Send message error:', error)
    return NextResponse.json(
      { 
        error: 'Internal server error', 
        details: error.message,
        stack: error.stack 
      },
      { status: 500 }
    )
  }
}