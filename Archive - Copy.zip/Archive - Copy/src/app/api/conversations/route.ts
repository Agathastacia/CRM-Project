import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import db from '@/lib/db';
import log from '@/lib/logger';

/**
 * GET - List conversations
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');
    const agentId = searchParams.get('agentId');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where: any = {};

    // Filter by status
    if (status) {
      where.status = status;
    }

    // Filter by agent (for non-admin, show only their conversations)
    if (agentId) {
      where.agentId = agentId;
    } else if (session.user.role === 'AGENT') {
      where.agentId = session.user.id;
    }

    const [conversations, total] = await Promise.all([
      db.conversation.findMany({
        where,
        include: {
          customer: {
            select: {
              id: true,
              name: true,
              phone: true,
              category: true,
              profilePictureUrl: true,
            },
          },
          agent: {
            select: {
              id: true,
              name: true,
              avatarUrl: true,
            },
          },
          messages: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
        orderBy: [
          { status: 'asc' },
          { lastMessageAt: 'desc' },
        ],
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.conversation.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: conversations,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });

  } catch (error) {
    log.error('Get conversations error', { error });
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
