import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

/**
 * GET /api/knowledge-base
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const subcategory = searchParams.get('subcategory')
    const isActive = searchParams.get('isActive')
    const q = searchParams.get('q')

    const where: any = {}

    if (category) {
      where.category = category
    }

    if (subcategory) {
      where.subcategory = subcategory
    }

    if (isActive !== null && isActive !== undefined) {
      where.isActive = isActive === 'true'
    }

    if (q) {
      where.OR = [
        { title: { contains: q, mode: 'insensitive' } },
        { content: { contains: q, mode: 'insensitive' } }
      ]
    }

    const knowledgeBase = await prisma.knowledgeBase.findMany({
      where,
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' }
      ]
    })

    return NextResponse.json({
      success: true,
      data: knowledgeBase
    })

  } catch (error: any) {
    console.error('❌ Fetch knowledge base error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * POST /api/knowledge-base
 */
export async function POST(request: NextRequest) {
  try {
    const { category, subcategory, title, content, keywords, priority, isActive } = await request.json();

    // Validasi
    if (!category || !title || !content) {
      return NextResponse.json(
        { error: 'Category, title, and content are required' },
        { status: 400 }
      )
    }

    // Parse keywords dengan aman
    let parsedKeywords = null;
    if (keywords && keywords.trim() !== '') {
      try {
        parsedKeywords = JSON.parse(keywords);
      } catch (e) {
        return NextResponse.json(
          { error: 'Invalid JSON format for keywords' },
          { status: 400 }
        )
      }
    }

    // Parse isActive dengan aman
    const parsedIsActive = typeof isActive === 'boolean' ? isActive : isActive === 'true';

    // Buat knowledge base entry baru
    const entry = await prisma.knowledgeBase.create({
      data: {
        category,
        subcategory: subcategory || null,
        title,
        content,
        keywords: parsedKeywords,
        priority: priority ? parseInt(priority) : 0,
        isActive: parsedIsActive
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Knowledge base entry created successfully',
      data: entry
    })

  } catch (error: any) {
    console.error('❌ Create knowledge base entry error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}