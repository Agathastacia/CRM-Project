import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

/**
 * GET /api/deals
 */
export async function GET(request: NextRequest) {
  try {
    const deals = await prisma.deal.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        customer: true,
        createdBy: true
      }
    })

    return NextResponse.json({
      success: true,
      data: deals
    })

  } catch (error: any) {
    console.error('❌ Fetch deals error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * POST /api/deals
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { customerId, title, description, value, status, expectedCloseDate } = await request.json();

    // Validasi
    if (!customerId || !title || !status) {
      return NextResponse.json(
        { error: 'Customer ID, title, and status are required' },
        { status: 400 }
      )
    }

    // Buat deal baru
    const deal = await prisma.deal.create({
      data: {
        title,
        description,
        value: value ? parseFloat(value) : undefined,
        stage: status, // ✅ Ganti status → stage
        expectedCloseDate: expectedCloseDate ? new Date(expectedCloseDate) : undefined,
        customer: {
          connect: { id: customerId }
        },
        createdBy: {
          connect: { id: session.user.id }
        }
      }
    });

    // Ambil deal dengan customer setelah create
    const dealWithCustomer = await prisma.deal.findUnique({
      where: { id: deal.id },
      include: {
        customer: true,
        createdBy: true
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Deal created successfully',
      data: dealWithCustomer
    })

  } catch (error: any) {
    console.error('❌ Create deal error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}