'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  LayoutDashboard, 
  MessageSquare, 
  Users, 
  Briefcase, 
  Package, 
  BookOpen, 
  Settings,
  FileText
} from 'lucide-react';

const menu = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Conversations', href: '/dashboard/conversations', icon: MessageSquare },
  { name: 'Customers', href: '/dashboard/customers', icon: Users },
  { name: 'Deals', href: '/dashboard/deals', icon: Briefcase },
  { name: 'Orders', href: '/dashboard/orders', icon: Package },
  { name: 'Knowledge Base', href: '/dashboard/knowledge-base', icon: BookOpen },
  { name: 'Reports', href: '/dashboard/reports', icon: FileText },
  { name: 'Settings', href: '/dashboard/settings', icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 bg-white border-r h-screen">
      <div className="p-6 font-bold text-xl">
        Krearte ⚙️
      </div>

      <nav className="px-4 space-y-1">
        {menu.map((item) => {
          // Perbaikan khusus untuk Dashboard
          const isActive = 
            item.href === '/dashboard'
              ? pathname === '/dashboard'
              : pathname === item.href || 
                (pathname.startsWith(item.href) && 
                 (pathname[item.href.length] === '/' || pathname.length === item.href.length));
          
          const Icon = item.icon;

          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-500'}`} />
              <span className="font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}