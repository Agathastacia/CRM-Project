'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Filter, RefreshCw, Plus, Edit, Trash2, X } from 'lucide-react';
import { formatDate } from '@/lib/utils';

interface Customer {
  id: string;
  name: string | null;
  phone: string;
}

interface Deal {
  id: string;
  customerId: string;
  title: string;
  description: string | null;
  value: number | null;
  stage: string;
  expectedCloseDate: string | null;
  closedAt: string | null;
  createdAt: string;
  customer: Customer;
}

export default function DealsPage() {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStage, setSelectedStage] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingDeal, setEditingDeal] = useState<Deal | null>(null);
  const [newDeal, setNewDeal] = useState({
    customerId: '',
    title: '',
    description: '',
    value: '',
    stage: 'PROSPECT',
    expectedCloseDate: ''
  });
  const [customers, setCustomers] = useState<Customer[]>([]);

  useEffect(() => {
    fetchDeals();
    fetchCustomers();
  }, [searchQuery, selectedStage]);

  const fetchDeals = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set('q', searchQuery);
      if (selectedStage) params.set('stage', selectedStage);
      
      const res = await fetch(`/api/deals?${params}`);
      const data = await res.json();
      if (data.success) {
        setDeals(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomers = async () => {
    try {
      const res = await fetch('/api/customers');
      const data = await res.json();
      if (data.success) {
        setCustomers(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch customers:', error);
    }
  };

  // Handle Add Deal
  const handleAddDeal = async () => {
    try {
      const res = await fetch('/api/deals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newDeal,
          status: newDeal.stage
        })
      });
      
      const data = await res.json();
      if (data.success) {
        fetchDeals();
        setShowAddForm(false);
        setNewDeal({
          customerId: '',
          title: '',
          description: '',
          value: '',
          stage: 'PROSPECT',
          expectedCloseDate: ''
        });
      }
    } catch (error) {
      console.error('Failed to add deal:', error);
    }
  };

  // Handle Edit Deal
  const handleEditDeal = (deal: Deal) => {
    setEditingDeal(deal);
    setNewDeal({
      customerId: deal.customerId,
      title: deal.title,
      description: deal.description || '',
      value: deal.value?.toString() || '',
      stage: deal.stage,
      expectedCloseDate: deal.expectedCloseDate || ''
    });
    setShowEditForm(true);
  };

  const handleUpdateDeal = async () => {
    if (!editingDeal) return;

    try {
      const res = await fetch(`/api/deals/${editingDeal.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newDeal,
          status: newDeal.stage
        })
      });
      
      const data = await res.json();
      if (data.success) {
        fetchDeals();
        setShowEditForm(false);
        setEditingDeal(null);
        setNewDeal({
          customerId: '',
          title: '',
          description: '',
          value: '',
          stage: 'PROSPECT',
          expectedCloseDate: ''
        });
      }
    } catch (error) {
      console.error('Failed to update deal:', error);
    }
  };

  // Handle Delete Deal
  const handleDeleteDeal = async (dealId: string) => {
    if (!confirm('Yakin ingin menghapus deal ini?')) return;

    try {
      const res = await fetch(`/api/deals/${dealId}`, {
        method: 'DELETE'
      });
      
      const data = await res.json();
      if (data.success) {
        fetchDeals();
      }
    } catch (error) {
      console.error('Failed to delete deal:', error);
    }
  };

  const stageOptions = [
    { value: '', label: 'Semua Stage' },
    { value: 'PROSPECT', label: 'Prospect', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'NEGOTIATION', label: 'Negotiation', color: 'bg-blue-100 text-blue-800' },
    { value: 'WON', label: 'Won', color: 'bg-green-100 text-green-800' },
    { value: 'LOST', label: 'Lost', color: 'bg-red-100 text-red-800' },
  ];

  const filteredDeals = (deals || []).filter((deal) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      deal.title.toLowerCase().includes(q) ||
      deal.customer.name?.toLowerCase().includes(q) ||
      deal.customer.phone.includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Deals</h1>
          <p className="text-muted-foreground">Kelola peluang penjualan</p>
        </div>
        <Button onClick={() => setShowAddForm(!showAddForm)}>
          <Plus className="h-4 w-4 mr-2" /> Tambah Deal
        </Button>
      </div>

      {/* Form Tambah/Edit Deal */}
      {(showAddForm || showEditForm) && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>
              {showEditForm ? 'Edit Deal' : 'Tambah Deal Baru'}
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingDeal(null);
                setNewDeal({
                  customerId: '',
                  title: '',
                  description: '',
                  value: '',
                  stage: 'PROSPECT',
                  expectedCloseDate: ''
                });
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Customer</label>
                <select
                  value={newDeal.customerId}
                  onChange={(e) => setNewDeal({...newDeal, customerId: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                  required
                >
                  <option value="">Pilih Customer</option>
                  {customers.map((customer) => (
                    <option key={customer.id} value={customer.id}>
                      {customer.name || customer.phone}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Judul Deal</label>
                <Input
                  value={newDeal.title}
                  onChange={(e) => setNewDeal({...newDeal, title: e.target.value})}
                  placeholder="Contoh: Proyek PVC Wallcoverings"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Deskripsi</label>
                <Input
                  value={newDeal.description}
                  onChange={(e) => setNewDeal({...newDeal, description: e.target.value})}
                  placeholder="Deskripsi deal"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Nilai Deal (Rp)</label>
                <Input
                  type="number"
                  value={newDeal.value}
                  onChange={(e) => setNewDeal({...newDeal, value: e.target.value})}
                  placeholder="Contoh: 50000000"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Stage</label>
                <select
                  value={newDeal.stage}
                  onChange={(e) => setNewDeal({...newDeal, stage: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                >
                  {stageOptions.filter(opt => opt.value).map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Expected Close Date</label>
                <Input
                  type="date"
                  value={newDeal.expectedCloseDate}
                  onChange={(e) => setNewDeal({...newDeal, expectedCloseDate: e.target.value})}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingDeal(null);
                setNewDeal({
                  customerId: '',
                  title: '',
                  description: '',
                  value: '',
                  stage: 'PROSPECT',
                  expectedCloseDate: ''
                });
              }}>Batal</Button>
              <Button onClick={showEditForm ? handleUpdateDeal : handleAddDeal}>
                {showEditForm ? 'Update Deal' : 'Simpan Deal'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari deal..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={selectedStage}
              onChange={(e) => setSelectedStage(e.target.value)}
              className="h-10 px-3 rounded-md border border-input bg-background text-sm"
            >
              {stageOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <Button variant="outline" size="sm" onClick={fetchDeals}>
              <RefreshCw className="h-4 w-4 mr-2" /> Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredDeals.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">💼</div>
              <h3 className="text-xl font-semibold">Tidak ada deal</h3>
              <p className="text-muted-foreground mt-2">Mulailah dengan menambahkan deal pertama Anda</p>
              <Button className="mt-4" size="lg" onClick={() => setShowAddForm(true)}>
                <Plus className="h-4 w-4 mr-2" /> Tambah Deal
              </Button>
            </div>
          ) : (
            <div className="divide-y">
              {filteredDeals.map((deal) => (
                <div key={deal.id} className="flex items-center gap-4 py-4 hover:bg-muted/50 px-2 -mx-2 rounded-lg transition-colors">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      💼
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold">{deal.title}</span>
                      <span className={`px-2 py-0.5 text-xs rounded-full ${stageOptions.find(opt => opt.value === deal.stage)?.color || 'bg-gray-100'}`}>
                        {stageOptions.find(opt => opt.value === deal.stage)?.label || deal.stage}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>Customer: {deal.customer.name || deal.customer.phone}</span>
                      {deal.value && <span>• Rp {deal.value.toLocaleString('id-ID')}</span>}
                      {deal.expectedCloseDate && <span>• Expected: {formatDate(deal.expectedCloseDate)}</span>}
                    </div>
                    {deal.description && (
                      <p className="text-sm mt-1 text-muted-foreground">
                        {deal.description}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Edit"
                      onClick={() => handleEditDeal(deal)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Hapus"
                      onClick={() => handleDeleteDeal(deal.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}