import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create admin user
  const adminPassword = await bcrypt.hash('krearte123', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@krearte.id' },
    update: {},
    create: {
      email: 'admin@krearte.id',
      name: 'Admin Krearte',
      phone: '6281234567890',
      passwordHash: adminPassword,
      role: 'ADMIN',
      isActive: true,
      isAvailable: true,
      maxLoad: 20,
    },
  });
  console.log('✅ Admin user created:', admin.email);

  // Create CS agents
  const agentPassword = await bcrypt.hash('agent123', 10);
  const agents = await Promise.all([
    prisma.user.upsert({
      where: { email: 'cs1@krearte.id' },
      update: {},
      create: {
        email: 'cs1@krearte.id',
        name: 'CS Rina',
        phone: '6281234567891',
        passwordHash: agentPassword,
        role: 'AGENT',
        isActive: true,
        isAvailable: true,
        maxLoad: 10,
      },
    }),
    prisma.user.upsert({
      where: { email: 'cs2@krearte.id' },
      update: {},
      create: {
        email: 'cs2@krearte.id',
        name: 'CS Budi',
        phone: '6281234567892',
        passwordHash: agentPassword,
        role: 'AGENT',
        isActive: true,
        isAvailable: true,
        maxLoad: 10,
      },
    }),
    prisma.user.upsert({
      where: { email: 'cs3@krearte.id' },
      update: {},
      create: {
        email: 'cs3@krearte.id',
        name: 'CS Dewi',
        phone: '6281234567893',
        passwordHash: agentPassword,
        role: 'AGENT',
        isActive: true,
        isAvailable: false,
        maxLoad: 10,
      },
    }),
  ]);
  console.log('✅ CS agents created:', agents.length);

  // Create designer
  const designerPassword = await bcrypt.hash('designer123', 10);
  const designer = await prisma.user.upsert({
    where: { email: 'designer@krearte.id' },
    update: {},
    create: {
      email: 'designer@krearte.id',
      name: 'Designer Andi',
      phone: '6281234567894',
      passwordHash: designerPassword,
      role: 'DESIGNER',
      isActive: true,
      isAvailable: true,
      maxLoad: 5,
    },
  });
  console.log('✅ Designer created:', designer.email);

  // Seed Knowledge Base
  const knowledgeItems = [
    {
      category: 'Produk',
      subcategory: 'Wallcovering',
      title: 'PVC Wallcovering',
      content: `PVC Wallcovering adalah bahan pelapis dinding berbahan dasar PVC yang tahan lama dan mudah dibersihkan. 

Jenis yang tersedia:
- Smooth Sand (tekstur halus seperti pasir)
- Industrial (tekstur industri modern)
- Linen (tekstur kain linen)
- Elegant (tekstur elegan premium)

Lebar material: 1.06m
Lebar print: 1.04m
Harga: Retail Rp 345.000/m2, Designer Rp 285.000/m2, Reseller Rp 215.000/m2

Cocok untuk: Hotel, kantor, rumah tinggal, ruang komersial`,
      keywords: ['pvc', 'wallcovering', 'smooth sand', 'industrial', 'linen'],
      priority: 10,
    },
    {
      category: 'Produk',
      subcategory: 'Wallcovering',
      title: 'Fabric-Back Wallcovering',
      content: `Fabric-Back Wallcovering adalah wallcovering premium dengan backing kain untuk hasil lebih mewah.

Jenis yang tersedia:
- Cross Hatch Linen (M69) - Lebar 1.4m
- Fine Sand Texture (M70) - Lebar 1.4m

Harga: Retail Rp 385.000/m2, Designer Rp 330.000/m2, Reseller Rp 230.000/m2

Keunggulan: Tekstur premium, tahan lama, mudah dipasang`,
      keywords: ['fabric', 'premium', 'cross hatch', 'fine sand'],
      priority: 9,
    },
    {
      category: 'Produk',
      subcategory: 'Special Effect',
      title: 'Metallic Wallcovering',
      content: `Wallcovering dengan efek metalik untuk tampilan mewah dan elegan.

Jenis:
- Abstract Embossing Texture-Metallic (L137) - Rp 750.000/m2 retail
- Silver/Gold Metallic - Rp 500.000/m2 retail
- Metallic Silver Japanese Silk - Rp 860.000/m2 retail

Catatan: Silver/Gold Metallic tidak bisa dipasang dengan sambungan (NON JOIN)`,
      keywords: ['metallic', 'silver', 'gold', 'embossing', 'mewah'],
      priority: 8,
    },
    {
      category: 'Layanan',
      subcategory: 'Jasa',
      title: 'Jasa Custom Print',
      content: `Krearte menyediakan jasa custom print untuk wallcovering sesuai desain Anda.

Jasa Print Bahan dari Customer:
- Bahan Standard: Rp 200.000/m2
- Karpet/Roller Blind: Rp 250.000/m2

Jasa Design/Re-draw:
- 1 Hari: Rp 150.000
- 1 Minggu: Rp 900.000
- 2 Minggu: Rp 1.800.000

Shutterstock Image: Rp 625.000 (Retail), Rp 320.000 (Reseller)

2.5D Print tambahan: Rp 500.000/m2`,
      keywords: ['custom', 'print', 'design', 'jasa'],
      priority: 10,
    },
    {
      category: 'FAQ',
      subcategory: 'Pemesanan',
      title: 'Cara Memesan',
      content: `Cara memesan wallcovering di Krearte:

1. Konsultasi kebutuhan (material, ukuran, lokasi)
2. Survey lokasi (jika diperlukan)
3. Penawaran harga / quotation
4. Approval desain (untuk custom print)
5. DP 50% untuk mulai produksi
6. Produksi 5-7 hari kerja
7. Pelunasan sebelum pengiriman
8. Pengiriman atau pemasangan

Minimal order: Tidak ada minimal order
Lead time: 5-7 hari kerja setelah desain approved dan DP diterima`,
      keywords: ['order', 'pesan', 'cara', 'proses'],
      priority: 10,
    },
    {
      category: 'FAQ',
      subcategory: 'Pengiriman',
      title: 'Informasi Pengiriman',
      content: `Pengiriman Krearte:

Area Surabaya: Free ongkir untuk order di atas Rp 2.000.000
Luar Surabaya: Menggunakan ekspedisi, biaya ditanggung pembeli

Jasa Pemasangan:
- Tersedia untuk area Surabaya dan sekitarnya
- Biaya pemasangan tergantung luas area dan tingkat kesulitan
- Tim installer profesional dan berpengalaman

Waktu pengiriman: 1-2 hari setelah produksi selesai (Surabaya)`,
      keywords: ['kirim', 'ongkir', 'pasang', 'instalasi'],
      priority: 8,
    },
  ];

  for (const item of knowledgeItems) {
    await prisma.knowledgeBase.upsert({
      where: { id: item.title.replace(/\s+/g, '-').toLowerCase() },
      update: item,
      create: {
        id: item.title.replace(/\s+/g, '-').toLowerCase(),
        ...item,
      },
    });
  }
  console.log('✅ Knowledge base seeded:', knowledgeItems.length, 'items');

  // Seed Products
  const products = [
    {
      sku: 'PVC-SS-106',
      name: 'PVC Wallcovering Smooth Sand',
      category: 'PVC Wallcovering',
      materialType: 'PVC Coated on Non-Woven',
      description: 'Tekstur halus seperti pasir, cocok untuk berbagai ruangan',
      width: 1.06,
      printWidth: 1.04,
      unit: 'm2',
      priceRetail: 345000,
      priceDesigner: 285000,
      priceReseller: 215000,
      priceWaste: 60000,
      stockQuantity: 500,
    },
    {
      sku: 'PVC-IND-106',
      name: 'PVC Wallcovering Industrial',
      category: 'PVC Wallcovering',
      materialType: 'PVC Coated on Non-Woven',
      description: 'Tekstur industrial modern',
      width: 1.06,
      printWidth: 1.04,
      unit: 'm2',
      priceRetail: 345000,
      priceDesigner: 285000,
      priceReseller: 215000,
      priceWaste: 60000,
      stockQuantity: 300,
    },
    {
      sku: 'FB-CHL-140',
      name: 'Cross Hatch Linen M69',
      category: 'Fabric-Back Wallcovering',
      materialType: 'Fabric-Back',
      description: 'Wallcovering premium dengan tekstur cross hatch linen',
      width: 1.40,
      printWidth: 1.38,
      unit: 'm2',
      priceRetail: 385000,
      priceDesigner: 330000,
      priceReseller: 230000,
      priceWaste: 80000,
      stockQuantity: 200,
    },
    {
      sku: 'FB-FST-140',
      name: 'Fine Sand Texture M70',
      category: 'Fabric-Back Wallcovering',
      materialType: 'Fabric-Back',
      description: 'Wallcovering premium dengan tekstur pasir halus',
      width: 1.40,
      printWidth: 1.38,
      unit: 'm2',
      priceRetail: 385000,
      priceDesigner: 330000,
      priceReseller: 230000,
      priceWaste: 80000,
      stockQuantity: 200,
    },
    {
      sku: 'MTL-AEM-137',
      name: 'Abstract Embossing Texture-Metallic',
      category: 'Special Effect',
      materialType: 'Metallic PVC',
      description: 'Wallcovering metalik dengan tekstur emboss abstrak',
      width: 1.37,
      printWidth: 1.35,
      unit: 'm2',
      priceRetail: 750000,
      priceDesigner: 600000,
      priceReseller: 400000,
      priceWaste: 90000,
      stockQuantity: 100,
    },
    {
      sku: 'MTL-SLV-107',
      name: 'Silver/Gold Metallic',
      category: 'Special Effect',
      materialType: 'Metallic PVC',
      description: 'Wallcovering metalik silver/gold (NON JOIN installation)',
      width: 1.07,
      printWidth: 1.05,
      unit: 'm2',
      priceRetail: 500000,
      priceDesigner: 400000,
      priceReseller: 250000,
      priceWaste: 80000,
      stockQuantity: 150,
    },
    {
      sku: 'SA-ART-152',
      name: 'Self-Adhesive Art Fabric',
      category: 'Self-Adhesive',
      materialType: 'Self-Adhesive Fabric',
      description: 'Wallpaper self-adhesive dengan tekstur art fabric',
      width: 1.52,
      printWidth: 1.50,
      unit: 'm2',
      priceRetail: 335000,
      priceDesigner: 285000,
      priceReseller: 200000,
      priceWaste: 90000,
      stockQuantity: 250,
    },
  ];

  for (const product of products) {
    await prisma.product.upsert({
      where: { sku: product.sku },
      update: product,
      create: product,
    });
  }
  console.log('✅ Products seeded:', products.length, 'items');

  console.log('🎉 Seeding completed!');
  console.log('\n📋 Login credentials:');
  console.log('   Admin: admin@krearte.id / krearte123');
  console.log('   CS: cs1@krearte.id / agent123');
  console.log('   Designer: designer@krearte.id / designer123');
}

main()
  .catch((e) => {
    console.error('❌ Seeding error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
