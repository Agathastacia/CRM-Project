export default function Header() {
  return (
    <header className="h-16 bg-white border-b px-6 flex items-center justify-between">
      <div className="font-medium">
        Krearte Automation
      </div>

      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-500">
          Admin
        </span>
        <div className="w-8 h-8 rounded-full bg-gray-300" />
      </div>
    </header>
  )
}
