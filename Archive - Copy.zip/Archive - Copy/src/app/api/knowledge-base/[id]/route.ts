import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

/**
 * GET /api/knowledge-base/[id]
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const entry = await prisma.knowledgeBase.findUnique({
      where: { id: params.id }
    });

    if (!entry) {
      return NextResponse.json(
        { error: 'Knowledge base entry not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: entry
    })

  } catch (error: any) {
    console.error('❌ Fetch knowledge base entry error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/knowledge-base/[id]
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { category, subcategory, title, content, keywords, priority, isActive } = await request.json();

    // Parse keywords dengan aman
    let parsedKeywords = null;
    if (keywords && keywords.trim() !== '') {
      try {
        parsedKeywords = JSON.parse(keywords);
      } catch (e) {
        return NextResponse.json(
          { error: 'Invalid JSON format for keywords' },
          { status: 400 }
        )
      }
    }

    // Parse isActive dengan aman
    const parsedIsActive = typeof isActive === 'boolean' ? isActive : isActive === 'true';

    // Update knowledge base entry
    const entry = await prisma.knowledgeBase.update({
      where: { id: params.id },
      data: {
        category,
        subcategory: subcategory || null,
        title,
        content,
        keywords: parsedKeywords,
        priority: priority ? parseInt(priority) : 0,
        isActive: parsedIsActive
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Knowledge base entry updated successfully',
      data: entry
    })

  } catch (error: any) {
    console.error('❌ Update knowledge base entry error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/knowledge-base/[id]
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.knowledgeBase.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      success: true,
      message: 'Knowledge base entry deleted successfully'
    })

  } catch (error: any) {
    console.error('❌ Delete knowledge base entry error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}