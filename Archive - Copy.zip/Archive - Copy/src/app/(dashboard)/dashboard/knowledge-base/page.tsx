'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, RefreshCw, Plus, Edit, Trash2, X, Tag, BookOpen } from 'lucide-react';
import { formatDate } from '@/lib/utils';

interface KnowledgeBaseEntry {
  id: string;
  category: string;
  subcategory: string | null;
  title: string;
  content: string;
  keywords: any;
  priority: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function KnowledgeBasePage() {
  const [entries, setEntries] = useState<KnowledgeBaseEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubcategory, setSelectedSubcategory] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState<KnowledgeBaseEntry | null>(null);
  const [newEntry, setNewEntry] = useState({
    category: '',
    subcategory: '',
    title: '',
    content: '',
    keywords: '',
    priority: '0',
    isActive: true
  });

  useEffect(() => {
    fetchEntries();
  }, [searchQuery, selectedCategory, selectedSubcategory, showInactive]);

  const fetchEntries = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set('q', searchQuery);
      if (selectedCategory) params.set('category', selectedCategory);
      if (selectedSubcategory) params.set('subcategory', selectedSubcategory);
      if (!showInactive) params.set('isActive', 'true');
      
      const res = await fetch(`/api/knowledge-base?${params}`);
      const data = await res.json();
      if (data.success) {
        setEntries(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle Add Entry
  const handleAddEntry = async () => {
    try {
      const res = await fetch('/api/knowledge-base', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry)
      });
      
      const data = await res.json();
      if (data.success) {
        fetchEntries();
        setShowAddForm(false);
        setNewEntry({
          category: '',
          subcategory: '',
          title: '',
          content: '',
          keywords: '',
          priority: '0',
          isActive: true
        });
      }
    } catch (error) {
      console.error('Failed to add entry:', error);
    }
  };

  // Handle Edit Entry
  const handleEditEntry = (entry: KnowledgeBaseEntry) => {
    setEditingEntry(entry);
    setNewEntry({
      category: entry.category,
      subcategory: entry.subcategory || '',
      title: entry.title,
      content: entry.content,
      keywords: entry.keywords ? JSON.stringify(entry.keywords) : '',
      priority: entry.priority.toString(),
      isActive: entry.isActive
    });
    setShowEditForm(true);
  };

  const handleUpdateEntry = async () => {
    if (!editingEntry) return;

    try {
      const res = await fetch(`/api/knowledge-base/${editingEntry.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEntry)
      });
      
      const data = await res.json();
      if (data.success) {
        fetchEntries();
        setShowEditForm(false);
        setEditingEntry(null);
        setNewEntry({
          category: '',
          subcategory: '',
          title: '',
          content: '',
          keywords: '',
          priority: '0',
          isActive: true
        });
      }
    } catch (error) {
      console.error('Failed to update entry:', error);
    }
  };

  // Handle Delete Entry
  const handleDeleteEntry = async (entryId: string) => {
    if (!confirm('Yakin ingin menghapus knowledge base entry ini?')) return;

    try {
      const res = await fetch(`/api/knowledge-base/${entryId}`, {
        method: 'DELETE'
      });
      
      const data = await res.json();
      if (data.success) {
        fetchEntries();
      }
    } catch (error) {
      console.error('Failed to delete entry:', error);
    }
  };

  const categories = [
    { value: '', label: 'Semua Kategori' },
    { value: 'PRODUCT', label: 'Product' },
    { value: 'PRICING', label: 'Pricing' },
    { value: 'INSTALLATION', label: 'Installation' },
    { value: 'MAINTENANCE', label: 'Maintenance' },
    { value: 'WARRANTY', label: 'Warranty' },
    { value: 'FAQ', label: 'FAQ' },
    { value: 'POLICY', label: 'Policy' }
  ];

  const filteredEntries = (entries || []).filter((entry) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      entry.title.toLowerCase().includes(q) ||
      entry.content.toLowerCase().includes(q)
    );
  });
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Knowledge Base</h1>
          <p className="text-muted-foreground">Kelola informasi produk & FAQ</p>
        </div>
        <Button onClick={() => setShowAddForm(!showAddForm)}>
          <Plus className="h-4 w-4 mr-2" /> Tambah Entry
        </Button>
      </div>

      {/* Form Tambah/Edit Entry */}
      {(showAddForm || showEditForm) && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>
              {showEditForm ? 'Edit Knowledge Base Entry' : 'Tambah Knowledge Base Entry Baru'}
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingEntry(null);
                setNewEntry({
                  category: '',
                  subcategory: '',
                  title: '',
                  content: '',
                  keywords: '',
                  priority: '0',
                  isActive: true
                });
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Kategori</label>
                <select
                  value={newEntry.category}
                  onChange={(e) => setNewEntry({...newEntry, category: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                  required
                >
                  <option value="">Pilih Kategori</option>
                  {categories.filter(opt => opt.value).map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Subkategori (Opsional)</label>
                <Input
                  value={newEntry.subcategory}
                  onChange={(e) => setNewEntry({...newEntry, subcategory: e.target.value})}
                  placeholder="Contoh: PVC Wallcoverings"
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm font-medium">Judul</label>
                <Input
                  value={newEntry.title}
                  onChange={(e) => setNewEntry({...newEntry, title: e.target.value})}
                  placeholder="Contoh: Cara Instalasi PVC Wallcovering"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm font-medium">Konten</label>
                <textarea
                  value={newEntry.content}
                  onChange={(e) => setNewEntry({...newEntry, content: e.target.value})}
                  placeholder="Isi knowledge base entry..."
                  className="w-full h-40 px-3 py-2 rounded-md border border-input bg-background text-sm resize-none"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Keywords (JSON)</label>
                <Input
                  value={newEntry.keywords}
                  onChange={(e) => setNewEntry({...newEntry, keywords: e.target.value})}
                  placeholder='Contoh: ["wallcovering", "installation"]'
                />
              </div>
              <div>
                <label className="text-sm font-medium">Priority</label>
                <Input
                  type="number"
                  value={newEntry.priority}
                  onChange={(e) => setNewEntry({...newEntry, priority: e.target.value})}
                  placeholder="0"
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm font-medium">Status</label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newEntry.isActive}
                    onChange={(e) => setNewEntry({...newEntry, isActive: e.target.checked})}
                    className="w-4 h-4"
                  />
                  <span>Aktif</span>
                </label>
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingEntry(null);
                setNewEntry({
                  category: '',
                  subcategory: '',
                  title: '',
                  content: '',
                  keywords: '',
                  priority: '0',
                  isActive: true
                });
              }}>Batal</Button>
              <Button onClick={showEditForm ? handleUpdateEntry : handleAddEntry}>
                {showEditForm ? 'Update Entry' : 'Simpan Entry'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari knowledge base..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="h-10 px-3 rounded-md border border-input bg-background text-sm"
            >
              {categories.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={showInactive}
                  onChange={(e) => setShowInactive(e.target.checked)}
                  className="w-4 h-4"
                />
                <span>Tampilkan Inactive</span>
              </label>
              <Button variant="outline" size="sm" onClick={fetchEntries}>
                <RefreshCw className="h-4 w-4 mr-2" /> Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📚</div>
              <h3 className="text-xl font-semibold">Tidak ada knowledge base entry</h3>
              <p className="text-muted-foreground mt-2">Mulailah dengan menambahkan entry pertama Anda</p>
              <Button className="mt-4" size="lg" onClick={() => setShowAddForm(true)}>
                <Plus className="h-4 w-4 mr-2" /> Tambah Entry
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredEntries.map((entry) => (
                <Card key={entry.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Tag className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium text-muted-foreground">
                          {entry.category}
                        </span>
                        {entry.subcategory && (
                          <span className="text-xs text-muted-foreground">
                            / {entry.subcategory}
                          </span>
                        )}
                      </div>
                      <span className={`px-2 py-0.5 text-xs rounded-full ${
                        entry.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {entry.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <CardTitle className="text-base mt-2">{entry.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {entry.content}
                    </p>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <BookOpen className="h-3 w-3" />
                        <span>Priority: {entry.priority}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          title="Edit"
                          onClick={() => handleEditEntry(entry)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          title="Hapus"
                          onClick={() => handleDeleteEntry(entry.id)}
                        >
                          <Trash2 className="h-3 w-3 text-red-500" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Created: {formatDate(entry.createdAt)}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}