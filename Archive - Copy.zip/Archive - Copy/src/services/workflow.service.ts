import axios from 'axios';
import db from '@/lib/db';
import log from '@/lib/logger';
import { Prisma } from '@prisma/client';
import type { WorkflowType, WorkflowStepType, WorkflowStepStatus } from '@prisma/client';

const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL || 'http://localhost:5678/webhook';

class WorkflowService {
  /**
   * Trigger a workflow in n8n
   */
  async trigger(
    workflowType: WorkflowType,
    referenceType: string,
    referenceId: string,
    data: Record<string, unknown>,
    createdById?: string
  ): Promise<string | null> {
    try {
      // Create workflow instance record
      const instance = await db.workflowInstance.create({
        data: {
          workflowType,
          referenceType,
          referenceId,
          status: 'PENDING',
          context: data as Prisma.InputJsonValue,
          createdById,
        },
      });

      // Trigger n8n webhook
      const webhookUrl = `${N8N_WEBHOOK_URL}/${workflowType.toLowerCase()}`;
      
      const response = await axios.post(webhookUrl, {
        workflowInstanceId: instance.id,
        workflowType,
        referenceType,
        referenceId,
        data,
        timestamp: new Date().toISOString(),
      }, {
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': process.env.N8N_API_KEY || '',
        },
        timeout: 10000,
      });

      // Update with n8n execution ID if returned
      if (response.data?.executionId) {
        await db.workflowInstance.update({
          where: { id: instance.id },
          data: {
            n8nExecutionId: response.data.executionId,
            status: 'IN_PROGRESS',
          },
        });
      }

      log.workflow('Workflow triggered', {
        workflowType,
        instanceId: instance.id,
        referenceType,
        referenceId,
      });

      return instance.id;

    } catch (error: any) {
      log.error('Workflow trigger error', {
        workflowType,
        referenceType,
        referenceId,
        error: error.message,
      });
      return null;
    }
  }

  /**
   * Update workflow status (called by n8n webhook)
   */
  async updateStatus(
    instanceId: string,
    status: 'IN_PROGRESS' | 'WAITING_HUMAN' | 'COMPLETED' | 'FAILED',
    data?: {
      currentStep?: string;
      context?: Record<string, unknown>;
      errorMessage?: string;
    }
  ): Promise<void> {
    try {
      await db.workflowInstance.update({
        where: { id: instanceId },
        data: {
          status,
          currentStep: data?.currentStep,
          context: data?.context as Prisma.InputJsonValue | undefined,
          errorMessage: data?.errorMessage,
          completedAt: ['COMPLETED', 'FAILED'].includes(status) ? new Date() : undefined,
        },
      });

      log.workflow('Workflow status updated', { instanceId, status });

    } catch (error) {
      log.error('Workflow status update error', { instanceId, error });
    }
  }

  /**
   * Log workflow step
   */
  async logStep(
    instanceId: string,
    stepName: string,
    stepType: WorkflowStepType,
    status: WorkflowStepStatus,
    data?: {
      inputData?: Record<string, unknown>;
      outputData?: Record<string, unknown>;
      errorMessage?: string;
      executedById?: string;
    }
  ): Promise<void> {
    try {
      await db.workflowStep.create({
        data: {
          workflowInstanceId: instanceId,
          stepName,
          stepType,
          status,
          inputData: data?.inputData as Prisma.InputJsonValue | undefined,
          outputData: data?.outputData as Prisma.InputJsonValue | undefined,
          errorMessage: data?.errorMessage,
          executedById: data?.executedById,
          startedAt: status === 'IN_PROGRESS' ? new Date() : undefined,
          completedAt: ['COMPLETED', 'FAILED', 'SKIPPED'].includes(status) ? new Date() : undefined,
        },
      });
    } catch (error) {
      log.error('Workflow step log error', { instanceId, stepName, error });
    }
  }

  /**
   * Create approval request (human-in-the-loop)
   */
  async createApproval(
    instanceId: string,
    approvalType: string,
    requestedById: string,
    assignedToId: string | null,
    requestData: Record<string, unknown>,
    dueInHours: number = 24
  ): Promise<string | null> {
    try {
      const dueDate = new Date();
      dueDate.setHours(dueDate.getHours() + dueInHours);

      const approval = await db.approval.create({
        data: {
          workflowInstanceId: instanceId,
          approvalType,
          requestedById,
          assignedToId,
          requestData: requestData as Prisma.InputJsonValue,
          dueDate,
          status: 'PENDING',
        },
      });

      // Update workflow to waiting
      await db.workflowInstance.update({
        where: { id: instanceId },
        data: { status: 'WAITING_HUMAN' },
      });

      log.workflow('Approval created', {
        instanceId,
        approvalId: approval.id,
        approvalType,
      });

      return approval.id;

    } catch (error) {
      log.error('Create approval error', { instanceId, approvalType, error });
      return null;
    }
  }

  /**
   * Respond to approval
   */
  async respondApproval(
    approvalId: string,
    status: 'APPROVED' | 'REJECTED',
    respondedById: string,
    responseData?: Record<string, unknown>
  ): Promise<boolean> {
    try {
      const approval = await db.approval.update({
        where: { id: approvalId },
        data: {
          status,
          respondedById,
          respondedAt: new Date(),
          responseData: responseData as Prisma.InputJsonValue | undefined,
        },
        include: { workflowInstance: true },
      });

      // Notify n8n to continue workflow
      const webhookUrl = `${N8N_WEBHOOK_URL}/approval-response`;
      await axios.post(webhookUrl, {
        workflowInstanceId: approval.workflowInstanceId,
        approvalId,
        status,
        responseData,
      }, {
        headers: { 'X-API-Key': process.env.N8N_API_KEY || '' },
      });

      log.workflow('Approval responded', { approvalId, status });
      return true;

    } catch (error) {
      log.error('Respond approval error', { approvalId, error });
      return false;
    }
  }

  /**
   * Get pending approvals for a user
   */
  async getPendingApprovals(userId: string) {
    return db.approval.findMany({
      where: {
        OR: [
          { assignedToId: userId },
          { assignedToId: null },
        ],
        status: 'PENDING',
        dueDate: { gte: new Date() },
      },
      include: {
        workflowInstance: true,
        requestedBy: {
          select: { id: true, name: true, email: true },
        },
      },
      orderBy: { dueDate: 'asc' },
    });
  }

  /**
   * Trigger design request workflow
   */
  async triggerDesignRequest(designRequestId: string, createdById: string): Promise<string | null> {
    const designRequest = await db.designRequest.findUnique({
      where: { id: designRequestId },
      include: {
        deal: true,
        customer: true,
      },
    });

    if (!designRequest) return null;

    return this.trigger(
      'DESIGN_REQUEST',
      'DesignRequest',
      designRequestId,
      {
        designRequest,
        customer: designRequest.customer,
        deal: designRequest.deal,
      },
      createdById
    );
  }

  /**
   * Trigger sales order workflow
   */
  async triggerSalesOrder(salesOrderId: string, createdById: string): Promise<string | null> {
    const salesOrder = await db.salesOrder.findUnique({
      where: { id: salesOrderId },
      include: {
        deal: true,
        customer: true,
      },
    });

    if (!salesOrder) return null;

    return this.trigger(
      'SALES_ORDER',
      'SalesOrder',
      salesOrderId,
      {
        salesOrder,
        customer: salesOrder.customer,
        deal: salesOrder.deal,
      },
      createdById
    );
  }

  /**
   * Trigger payment tracking workflow
   */
  async triggerPaymentTracking(salesOrderId: string): Promise<string | null> {
    const salesOrder = await db.salesOrder.findUnique({
      where: { id: salesOrderId },
      include: { customer: true },
    });

    if (!salesOrder) return null;

    return this.trigger(
      'PAYMENT_TRACKING',
      'SalesOrder',
      salesOrderId,
      {
        salesOrder,
        customer: salesOrder.customer,
        paymentDueDate: salesOrder.paymentDueDate,
      }
    );
  }

  /**
   * Trigger follow-up workflow
   */
  async triggerFollowUp(
    dealId: string,
    followUpType: string,
    scheduledFor: Date,
    message: string
  ): Promise<string | null> {
    const deal = await db.deal.findUnique({
      where: { id: dealId },
      include: {
        customer: true,
        assignedAgent: true,
      },
    });

    if (!deal) return null;

    return this.trigger(
      'FOLLOWUP',
      'Deal',
      dealId,
      {
        deal,
        customer: deal.customer,
        agent: deal.assignedAgent,
        followUpType,
        scheduledFor,
        message,
      }
    );
  }
}

export const workflowService = new WorkflowService();
export default workflowService;
