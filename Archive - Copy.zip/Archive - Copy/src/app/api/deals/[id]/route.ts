import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

/**
 * GET /api/deals/[id]
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const deal = await prisma.deal.findUnique({
      where: { id: params.id },
      include: {
        customer: true,
        createdBy: true
      }
    });

    if (!deal) {
      return NextResponse.json(
        { error: 'Deal not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: deal
    })

  } catch (error: any) {
    console.error('❌ Fetch deal error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/deals/[id]
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { customerId, title, description, value, status, expectedCloseDate } = await request.json();

    // Update deal
    const deal = await prisma.deal.update({
      where: { id: params.id },
      data: {
        title,
        description,
        value: value ? parseFloat(value) : undefined,
        stage: status, // ✅ Ganti status → stage
        expectedCloseDate: expectedCloseDate ? new Date(expectedCloseDate) : undefined,
        customer: {
          connect: { id: customerId }
        },
        createdBy: {
          connect: { id: session.user.id }
        }
      }
    });

    // Ambil deal dengan customer setelah update
    const dealWithCustomer = await prisma.deal.findUnique({
      where: { id: deal.id },
      include: {
        customer: true,
        createdBy: true
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Deal updated successfully',
      data: dealWithCustomer
    })

  } catch (error: any) {
    console.error('❌ Update deal error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/deals/[id]
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.deal.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      success: true,
      message: 'Deal deleted successfully'
    })

  } catch (error: any) {
    console.error('❌ Delete deal error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}