'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Filter, RefreshCw, Plus, Edit, Trash2, X } from 'lucide-react';
import { getInitials, formatDate, truncate } from '@/lib/utils';

interface Customer {
  id: string;
  name: string | null;
  phone: string;
  email: string | null;
  category: string;
  companyName: string | null;
  city: string | null;
  createdAt: string;
  conversations: Array<{ lastMessageAt: string }>;
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    phone: '',
    email: '',
    category: 'RETAIL',
    companyName: '',
    city: ''
  });

  useEffect(() => {
    fetchCustomers();
  }, [searchQuery, selectedCategory]);

  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set('q', searchQuery);
      if (selectedCategory) params.set('category', selectedCategory);
      
      const res = await fetch(`/api/customers?${params}`);
      const data = await res.json();
      if (data.success) {
        setCustomers(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle Add Customer
  const handleAddCustomer = async () => {
    try {
      const res = await fetch('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCustomer)
      });
      
      const data = await res.json();
      if (data.success) {
        fetchCustomers();
        setShowAddForm(false);
        setNewCustomer({
          name: '',
          phone: '',
          email: '',
          category: 'RETAIL',
          companyName: '',
          city: ''
        });
      }
    } catch (error) {
      console.error('Failed to add customer:', error);
    }
  };

  // Handle Edit Customer
  const handleEditCustomer = (customer: Customer) => {
    setEditingCustomer(customer);
    setNewCustomer({
      name: customer.name || '',
      phone: customer.phone,
      email: customer.email || '',
      category: customer.category,
      companyName: customer.companyName || '',
      city: customer.city || ''
    });
    setShowEditForm(true);
  };

  const handleUpdateCustomer = async () => {
    if (!editingCustomer) return;

    try {
      const res = await fetch(`/api/customers/${editingCustomer.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCustomer)
      });
      
      const data = await res.json();
      if (data.success) {
        fetchCustomers();
        setShowEditForm(false);
        setEditingCustomer(null);
        setNewCustomer({
          name: '',
          phone: '',
          email: '',
          category: 'RETAIL',
          companyName: '',
          city: ''
        });
      }
    } catch (error) {
      console.error('Failed to update customer:', error);
    }
  };

  // Handle Delete Customer
  const handleDeleteCustomer = async (customerId: string) => {
    if (!confirm('Yakin ingin menghapus customer ini?')) return;

    try {
      const res = await fetch(`/api/customers/${customerId}`, {
        method: 'DELETE'
      });
      
      const data = await res.json();
      if (data.success) {
        fetchCustomers();
      }
    } catch (error) {
      console.error('Failed to delete customer:', error);
    }
  };

  const categories = [
    { value: '', label: 'Semua Kategori' },
    { value: 'RETAIL', label: 'Retail' },
    { value: 'CORPORATE', label: 'Corporate' },
    { value: 'INDIVIDUAL', label: 'Individual' },
  ];

  const filteredCustomers = customers.filter((customer) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      customer.name?.toLowerCase().includes(q) ||
      customer.phone.includes(q) ||
      customer.email?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Customers</h1>
          <p className="text-muted-foreground">Kelola data pelanggan</p>
        </div>
        <Button onClick={() => setShowAddForm(!showAddForm)}>
          <Plus className="h-4 w-4 mr-2" /> Tambah Pelanggan
        </Button>
      </div>

      {/* Form Tambah/Edit Pelanggan */}
      {(showAddForm || showEditForm) && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>
              {showEditForm ? 'Edit Pelanggan' : 'Tambah Pelanggan Baru'}
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingCustomer(null);
                setNewCustomer({
                  name: '',
                  phone: '',
                  email: '',
                  category: 'RETAIL',
                  companyName: '',
                  city: ''
                });
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Nama</label>
                <Input
                  value={newCustomer.name}
                  onChange={(e) => setNewCustomer({...newCustomer, name: e.target.value})}
                  placeholder="Nama lengkap"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Nomor Telepon</label>
                <Input
                  value={newCustomer.phone}
                  onChange={(e) => setNewCustomer({...newCustomer, phone: e.target.value})}
                  placeholder="Contoh: 6281234567890"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Email</label>
                <Input
                  value={newCustomer.email}
                  onChange={(e) => setNewCustomer({...newCustomer, email: e.target.value})}
                  placeholder="email@contoh.com"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Kategori</label>
                <select
                  value={newCustomer.category}
                  onChange={(e) => setNewCustomer({...newCustomer, category: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                >
                  <option value="RETAIL">Retail</option>
                  <option value="CORPORATE">Corporate</option>
                  <option value="INDIVIDUAL">Individual</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Nama Perusahaan</label>
                <Input
                  value={newCustomer.companyName}
                  onChange={(e) => setNewCustomer({...newCustomer, companyName: e.target.value})}
                  placeholder="Nama perusahaan (opsional)"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Kota</label>
                <Input
                  value={newCustomer.city}
                  onChange={(e) => setNewCustomer({...newCustomer, city: e.target.value})}
                  placeholder="Kota"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingCustomer(null);
                setNewCustomer({
                  name: '',
                  phone: '',
                  email: '',
                  category: 'RETAIL',
                  companyName: '',
                  city: ''
                });
              }}>Batal</Button>
              <Button onClick={showEditForm ? handleUpdateCustomer : handleAddCustomer}>
                {showEditForm ? 'Update Pelanggan' : 'Simpan Pelanggan'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari nama, nomor, atau email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="h-10 px-3 rounded-md border border-input bg-background text-sm"
            >
              {categories.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <Button variant="outline" size="sm" onClick={fetchCustomers}>
              <RefreshCw className="h-4 w-4 mr-2" /> Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredCustomers.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">👥</div>
              <h3 className="text-xl font-semibold">Tidak ada pelanggan</h3>
              <p className="text-muted-foreground mt-2">Mulailah dengan menambahkan pelanggan pertama Anda</p>
              <Button className="mt-4" size="lg" onClick={() => setShowAddForm(true)}>
                <Plus className="h-4 w-4 mr-2" /> Tambah Pelanggan
              </Button>
            </div>
          ) : (
            <div className="divide-y">
              {filteredCustomers.map((customer) => (
                <div key={customer.id} className="flex items-center gap-4 py-4 hover:bg-muted/50 px-2 -mx-2 rounded-lg transition-colors">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      {getInitials(customer.name || customer.phone)}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold">{customer.name || customer.phone}</span>
                      <span className="px-2 py-0.5 text-xs rounded-full bg-muted">
                        {customer.category}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{customer.phone}</span>
                      {customer.email && <span>• {customer.email}</span>}
                      {customer.companyName && <span>• {customer.companyName}</span>}
                      <span>• {formatDate(customer.createdAt)}</span>
                    </div>
                    {customer.conversations[0] && (
                      <p className="text-xs mt-1 text-muted-foreground">
                        Terakhir aktif: {formatDate(customer.conversations[0].lastMessageAt)}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Edit"
                      onClick={() => handleEditCustomer(customer)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Hapus"
                      onClick={() => handleDeleteCustomer(customer.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}