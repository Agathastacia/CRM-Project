import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { parseAmount } from '@/lib/utils'

/**
 * GET /api/orders
 */
export async function GET(request: NextRequest) {
  try {
    const orders = await prisma.order.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        customer: true,
        deal: true,
        creator: true
      }
    })

    return NextResponse.json({
      success: true,
      data: orders
    })

  } catch (error: any) {
    console.error('❌ Fetch orders error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * POST /api/orders
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { customerId, dealId, orderNumber, status, paymentStatus, totalAmount, shippingAddress, notes } = await request.json();

    // Validasi
    if (!customerId || !orderNumber || !status) {
      return NextResponse.json(
        { error: 'Customer ID, order number, and status are required' },
        { status: 400 }
      )
    }

    // Buat order baru
    const order = await prisma.order.create({
      data: {
        orderNumber,
        status,
        paymentStatus: paymentStatus || 'UNPAID',
        totalAmount: totalAmount ? parseAmount(totalAmount) : undefined,
        shippingAddress,
        notes,
        customer: {
          connect: { id: customerId }
        },
        deal: dealId ? {
          connect: { id: dealId }
        } : undefined,
        creator: {
          connect: { id: session.user.id }
        }
      }
    });

    // Ambil order dengan relasi
    const orderWithRelations = await prisma.order.findUnique({
      where: { id: order.id },
      include: {
        customer: true,
        deal: true,
        creator: true
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Order created successfully',
      data: orderWithRelations
    })

  } catch (error: any) {
    // Handle unique constraint violation
    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'Order number already exists' },
        { status: 400 }
      )
    }
    
    console.error('❌ Create order error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}