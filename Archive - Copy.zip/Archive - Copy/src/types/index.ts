import { 
  User, 
  Customer, 
  Conversation, 
  Message, 
  Deal, 
  SalesOrder,
  DesignRequest,
  Product,
  KnowledgeBase,
} from '@prisma/client';

// Re-export Prisma types
export type {
  User,
  Customer,
  Conversation,
  Message,
  Deal,
  SalesOrder,
  DesignRequest,
  Product,
  KnowledgeBase,
};

// Extended types with relations
export type ConversationWithRelations = Conversation & {
  customer: Customer;
  agent: User | null;
  messages: Message[];
};

export type DealWithRelations = Deal & {
  customer: Customer;
  assignedAgent: User | null;
  followUps: FollowUp[];
  designRequests: DesignRequest[];
  salesOrders: SalesOrder[];
};

export type MessageWithAgent = Message & {
  agent: User | null;
};

// API Response types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

// WhatsApp types
export interface WhatsAppMessage {
  from: string;
  id: string;
  timestamp: string;
  type: 'text' | 'image' | 'document' | 'audio' | 'video' | 'location' | 'contacts' | 'interactive';
  text?: { body: string };
  image?: { id: string; caption?: string; mime_type: string };
  document?: { id: string; caption?: string; mime_type: string; filename: string };
  audio?: { id: string; mime_type: string };
  video?: { id: string; caption?: string; mime_type: string };
  location?: { latitude: number; longitude: number; name?: string; address?: string };
  contacts?: Array<{ name: { formatted_name: string }; phones: Array<{ phone: string }> }>;
  interactive?: {
    type: 'button_reply' | 'list_reply';
    button_reply?: { id: string; title: string };
    list_reply?: { id: string; title: string };
  };
}

export interface WhatsAppWebhookPayload {
  object: string;
  entry: Array<{
    id: string;
    changes: Array<{
      field: string;
      value: {
        messaging_product: string;
        metadata: { phone_number_id: string; display_phone_number: string };
        contacts?: Array<{ wa_id: string; profile: { name: string } }>;
        messages?: WhatsAppMessage[];
        statuses?: Array<{
          id: string;
          status: 'sent' | 'delivered' | 'read' | 'failed';
          timestamp: string;
          recipient_id: string;
        }>;
      };
    }>;
  }>;
}

// AI Chatbot types
export interface ChatbotResponse {
  message: string;
  handoff: boolean;
  handoffReason?: string;
  handoffMessage?: string;
  collectedData: BotCollectedData;
}

export interface BotCollectedData {
  name?: string;
  needs?: string;
  material?: string;
  size?: string;
  location?: string;
  category?: string;
  budget?: string;
  notes?: string;
}

// Dashboard stats
export interface DashboardStats {
  waitingCount: number;
  activeCount: number;
  resolvedToday: number;
  totalCustomers: number;
  activeDeals: number;
  availableAgents: number;
}

// Workflow types
export interface WorkflowTriggerPayload {
  workflowType: string;
  referenceType: string;
  referenceId: string;
  data: Record<string, unknown>;
}

// n8n types
export interface N8nWebhookPayload {
  workflowInstanceId: string;
  status: 'completed' | 'failed';
  step?: string;
  data?: Record<string, unknown>;
  error?: string;
}

// Socket.IO event types
export interface ServerToClientEvents {
  'message:new': (data: { conversationId: string; message: Message }) => void;
  'conversation:assigned': (data: { conversation: Conversation }) => void;
  'conversation:waiting': (data: { conversationId: string; customerName: string }) => void;
  'agent:status': (data: { agentId: string; isAvailable: boolean }) => void;
  'notification': (data: { type: string; message: string }) => void;
}

export interface ClientToServerEvents {
  'join:conversation': (conversationId: string) => void;
  'leave:conversation': (conversationId: string) => void;
  'join:agent': (agentId: string) => void;
  'typing:start': (conversationId: string) => void;
  'typing:stop': (conversationId: string) => void;
}

// Form types
export interface LoginForm {
  email: string;
  password: string;
}

export interface CustomerForm {
  name: string;
  phone: string;
  email?: string;
  category: string;
  companyName?: string;
  address?: string;
  city?: string;
  notes?: string;
}

export interface DealForm {
  customerId: string;
  title: string;
  description?: string;
  value: number;
  expectedCloseDate?: Date;
}

export interface FollowUp {
  id: string;
  dealId: string;
  agentId: string;
  type: string;
  title: string;
  description?: string;
  dueDate: Date;
  isCompleted: boolean;
  completedAt?: Date;
  result?: string;
  createdAt: Date;
}
