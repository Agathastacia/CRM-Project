import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

/**
 * GET /api/customers
 */
export async function GET(request: NextRequest) {
  try {
    const customers = await prisma.customer.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        conversations: {
          where: { status: 'BOT_HANDLING' },
          take: 1,
          orderBy: { lastMessageAt: 'desc' }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: customers
    })

  } catch (error: any) {
    console.error('❌ Fetch customers error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * POST /api/customers
 */
export async function POST(request: NextRequest) {
  try {
    const { name, phone, email, category, companyName, city } = await request.json();

    // Validasi
    if (!phone) {
      return NextResponse.json(
        { error: 'Phone is required' },
        { status: 400 }
      )
    }

    // Cek apakah phone sudah ada
    const existingCustomer = await prisma.customer.findUnique({
      where: { phone }
    });

    if (existingCustomer) {
      return NextResponse.json(
        { error: 'Customer with this phone already exists' },
        { status: 400 }
      )
    }

    // Buat customer baru
    const customer = await prisma.customer.create({
      data: {
        name,
        phone,
        email,
        category,
        companyName,
        city
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Customer created successfully',
      data: customer
    })

  } catch (error: any) {
    console.error('❌ Create customer error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}