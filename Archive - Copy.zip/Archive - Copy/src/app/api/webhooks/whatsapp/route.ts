import { NextRequest, NextResponse } from 'next/server';
import log from '@/lib/logger';
import conversationService from '@/services/conversation.service';
import db from '@/lib/db';
import type { WhatsAppWebhookPayload } from '@/types';

const VERIFY_TOKEN = process.env.WA_WEBHOOK_VERIFY_TOKEN || 'krearte-verify-token';

/**
 * GET - Webhook verification (required by Meta)
 */
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  
  const mode = searchParams.get('hub.mode');
  const token = searchParams.get('hub.verify_token');
  const challenge = searchParams.get('hub.challenge');

  log.whatsapp('Webhook verification request', { mode, token });

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    log.whatsapp('Webhook verified successfully');
    return new NextResponse(challenge, { status: 200 });
  }

  log.warn('Webhook verification failed');
  return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
}

/**
 * POST - Receive incoming messages and status updates
 */
export async function POST(request: NextRequest) {
  try {
    const body: WhatsAppWebhookPayload = await request.json();

    log.whatsapp('Webhook received', { 
      object: body.object,
      entries: body.entry?.length 
    });

    // Process in background, return 200 immediately
    // This prevents WhatsApp from retrying
    processWebhook(body).catch(error => {
      log.error('Background webhook processing error', { error });
    });

    return NextResponse.json({ status: 'ok' }, { status: 200 });

  } catch (error) {
    log.error('Webhook error', { error });
    return NextResponse.json({ status: 'ok' }, { status: 200 }); // Still return 200
  }
}

/**
 * Process webhook payload in background
 */
async function processWebhook(payload: WhatsAppWebhookPayload): Promise<void> {
  if (payload.object !== 'whatsapp_business_account') {
    return;
  }

  for (const entry of payload.entry) {
    for (const change of entry.changes) {
      if (change.field !== 'messages') continue;

      const value = change.value;

      // Handle incoming messages
      if (value.messages && value.messages.length > 0) {
        for (const message of value.messages) {
          const contact = value.contacts?.find(c => c.wa_id === message.from);
          const senderName = contact?.profile?.name;

          log.whatsapp('Processing incoming message', {
            from: message.from,
            type: message.type,
            messageId: message.id,
          });

          await conversationService.handleIncomingMessage(
            message,
            message.from,
            senderName
          );
        }
      }

      // Handle status updates
      if (value.statuses && value.statuses.length > 0) {
        for (const status of value.statuses) {
          await updateMessageStatus(status.id, status.status);
        }
      }
    }
  }
}

/**
 * Update message status in database
 */
async function updateMessageStatus(
  waMessageId: string,
  status: 'sent' | 'delivered' | 'read' | 'failed'
): Promise<void> {
  try {
    const statusMap: Record<string, string> = {
      'sent': 'SENT',
      'delivered': 'DELIVERED',
      'read': 'READ',
      'failed': 'FAILED',
    };

    await db.message.updateMany({
      where: { waMessageId },
      data: { waStatus: statusMap[status] as any },
    });

    log.whatsapp('Message status updated', { waMessageId, status });

  } catch (error) {
    // Non-critical, just log
    log.debug('Message status update failed', { waMessageId, error });
  }
}
