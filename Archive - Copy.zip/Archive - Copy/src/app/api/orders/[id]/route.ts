import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { parseAmount } from '@/lib/utils'

/**
 * GET /api/orders/[id]
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const order = await prisma.order.findUnique({
      where: { id: params.id },
      include: {
        customer: true,
        deal: true,
        creator: true
      }
    });

    if (!order) {
      return NextResponse.json(
        { error: 'Order not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: order
    })

  } catch (error: any) {
    console.error('❌ Fetch order error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/orders/[id]
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { customerId, dealId, orderNumber, status, paymentStatus, totalAmount, shippingAddress, notes } = await request.json();

    // Update order
    const order = await prisma.order.update({
      where: { id: params.id },
      data: {
        orderNumber,
        status,
        paymentStatus,
        totalAmount: totalAmount ? parseAmount(totalAmount) : undefined,
        shippingAddress,
        notes,
        customer: {
          connect: { id: customerId }
        },
        deal: dealId ? {
          connect: { id: dealId }
        } : undefined,
        creator: {
          connect: { id: session.user.id }
        }
      }
    });

    // Ambil order dengan relasi
    const orderWithRelations = await prisma.order.findUnique({
      where: { id: order.id },
      include: {
        customer: true,
        deal: true,
        creator: true
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Order updated successfully',
      data: orderWithRelations
    })

  } catch (error: any) {
    console.error('❌ Update order error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/orders/[id]
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.order.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      success: true,
      message: 'Order deleted successfully'
    })

  } catch (error: any) {
    console.error('❌ Delete order error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}