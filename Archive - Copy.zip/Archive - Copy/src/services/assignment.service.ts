import db from '@/lib/db';
import log from '@/lib/logger';

class AssignmentService {
  /**
   * Auto-assign conversation to available agent (least-busy algorithm)
   */
  async autoAssign(conversationId: string): Promise<string | null> {
    try {
      // Find least busy available agent
      const agent = await db.user.findFirst({
        where: {
          isAvailable: true,
          isActive: true,
          role: { in: ['AGENT', 'ADMIN', 'SUPERVISOR'] },
          currentLoad: { lt: db.user.fields.maxLoad },
        },
        orderBy: [
          { currentLoad: 'asc' },
          { lastActiveAt: 'desc' },
        ],
      });

      if (!agent) {
        log.info('No available agents for auto-assignment', { conversationId });
        return null;
      }

      // Assign conversation
      await db.$transaction([
        db.conversation.update({
          where: { id: conversationId },
          data: {
            agentId: agent.id,
            status: 'AGENT_HANDLING',
            assignedAt: new Date(),
          },
        }),
        db.user.update({
          where: { id: agent.id },
          data: {
            currentLoad: { increment: 1 },
          },
        }),
      ]);

      log.info('Conversation auto-assigned', { 
        conversationId, 
        agentId: agent.id, 
        agentName: agent.name 
      });

      return agent.id;

    } catch (error) {
      log.error('Auto-assignment error', { conversationId, error });
      return null;
    }
  }

  /**
   * Manual assign conversation to specific agent
   */
  async assignToAgent(
    conversationId: string, 
    agentId: string,
    currentAgentId?: string
  ): Promise<boolean> {
    try {
      const operations = [
        db.conversation.update({
          where: { id: conversationId },
          data: {
            agentId,
            status: 'AGENT_HANDLING',
            assignedAt: new Date(),
          },
        }),
        db.user.update({
          where: { id: agentId },
          data: { currentLoad: { increment: 1 } },
        }),
      ];

      // Decrement old agent's load if reassigning
      if (currentAgentId) {
        operations.push(
          db.user.update({
            where: { id: currentAgentId },
            data: { currentLoad: { decrement: 1 } },
          })
        );
      }

      await db.$transaction(operations);

      log.info('Conversation assigned', { conversationId, agentId });
      return true;

    } catch (error) {
      log.error('Assignment error', { conversationId, agentId, error });
      return false;
    }
  }

  /**
   * Release conversation (when resolved or transferred)
   */
  async releaseConversation(conversationId: string, agentId: string): Promise<void> {
    try {
      await db.user.update({
        where: { id: agentId },
        data: { currentLoad: { decrement: 1 } },
      });
    } catch (error) {
      log.error('Release conversation error', { conversationId, agentId, error });
    }
  }

  /**
   * Process waiting queue - called periodically
   */
  async processWaitingQueue(): Promise<number> {
    try {
      const waitingConversations = await db.conversation.findMany({
        where: { status: 'WAITING_ASSIGNMENT' },
        orderBy: [
          { priority: 'desc' },
          { startedAt: 'asc' },
        ],
        take: 10,
      });

      let assigned = 0;

      for (const conv of waitingConversations) {
        const agentId = await this.autoAssign(conv.id);
        if (agentId) {
          assigned++;
        } else {
          // No more available agents
          break;
        }
      }

      return assigned;

    } catch (error) {
      log.error('Process waiting queue error', { error });
      return 0;
    }
  }

  /**
   * Get available agents list
   */
  async getAvailableAgents() {
    return db.user.findMany({
      where: {
        isAvailable: true,
        isActive: true,
        role: { in: ['AGENT', 'ADMIN', 'SUPERVISOR'] },
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        currentLoad: true,
        maxLoad: true,
        lastActiveAt: true,
      },
      orderBy: { currentLoad: 'asc' },
    });
  }
}

export const assignmentService = new AssignmentService();
export default assignmentService;
