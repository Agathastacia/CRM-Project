import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

/**
 * Simple keyword matcher
 */
function extractKeywords(message: string): string[] {
  return message.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 2)
}

/**
 * Cari jawaban di knowledge base
 */
async function findKnowledgeBaseAnswer(message: string): Promise<string | null> {
  const keywords = extractKeywords(message)
  
  if (keywords.length === 0) return null

  try {
    // Cari berdasarkan title
    const kb = await prisma.knowledgeBase.findFirst({
      where: {
        title: { contains: message.toLowerCase() },
        isActive: true
      }
    })

    if (kb) return kb.content

    // Cari berdasarkan keywords
    for (const keyword of keywords) {
      const kb = await prisma.knowledgeBase.findFirst({
        where: {
          OR: [
            { title: { contains: keyword } },
            { content: { contains: keyword } }
          ],
          isActive: true
        },
        orderBy: { priority: 'asc' }
      })

      if (kb) return kb.content
    }

    return null
  } catch (error) {
    console.error('Knowledge base query error:', error)
    return null
  }
}

/**
 * POST /api/test-chat
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const message = body.message
    
    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      )
    }

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    console.log('📝 Test chat received:', message)
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')

    // Cari jawaban
    const answer = await findKnowledgeBaseAnswer(message)
    const finalReply = answer || 'Terima kasih atas pertanyaan Anda. Tim sales Krearte akan segera menghubungi Anda untuk informasi lebih detail. 😊'

    console.log('💬 Auto-reply:', finalReply)

    // === SIMPAN KE DATABASE ===
    try {
      // Cari customer dengan phone yang benar
      const customer = await prisma.customer.findFirst({
        where: { phone: '6281234567890' }
      })

      if (!customer) {
        console.warn('⚠️ Customer not found, skipping conversation save')
        return NextResponse.json({
          success: true,
          customerReply: finalReply,
          warning: 'Customer not found in database'
        })
      }

      // Buat conversation baru dengan agent ID yang benar
      const conversation = await prisma.conversation.create({
        data: {
          customerId: customer.id,
          agentId: 'cmlewsdvh0000d4mduj8h2loz',
          status: 'BOT_HANDLING',
          messages: {
            create: [
              { content: message, senderType: 'CUSTOMER' },
              { content: finalReply, senderType: 'SYSTEM' }
            ]
          },
          lastMessageAt: new Date()
        },
        include: {
          messages: true
        }
      })

      console.log('✅ Conversation saved:', conversation.id)

    } catch (dbError: any) {
      console.error('❌ Database save error:', dbError.message)
      console.error('Error details:', {
        code: dbError.code,
        meta: dbError.meta
      })
      // Tetap return reply meskipun gagal simpan
    }

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')

    return NextResponse.json({
      success: true,
      customerReply: finalReply,
      matchedKeywords: extractKeywords(message)
    })

  } catch (error: any) {
    console.error('❌ Test chat error:', error)
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error.message 
      },
      { status: 500 }
    )
  }
}