# Krearte Automation Platform

Platform otomasi end-to-end untuk Krearte Mitra Artisan - WhatsApp Chat, AI Chatbot, CRM, dan Workflow Orchestration.

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Database**: MySQL 8.0 + Prisma ORM
- **Authentication**: NextAuth.js
- **AI**: Claude API (Anthropic)
- **WhatsApp**: Meta Cloud API
- **Styling**: TailwindCSS + shadcn/ui
- **Workflow**: n8n (self-hosted)

## Prerequisites

- Node.js 18+
- MySQL 8.0
- npm atau yarn

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Setup Environment

```bash
cp .env.example .env
```

Edit `.env` dengan kredensial yang sesuai:

```env
# Database
DATABASE_URL="mysql://user:password@localhost:3306/krearte_platform"

# NextAuth
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-key

# WhatsApp (dari Meta Developer)
WA_PHONE_NUMBER_ID=your-phone-number-id
WA_ACCESS_TOKEN=your-access-token
WA_WEBHOOK_VERIFY_TOKEN=your-verify-token

# Claude API
ANTHROPIC_API_KEY=sk-ant-your-key
```

### 3. Setup Database

```bash
# Generate Prisma client
npm run db:generate

# Push schema ke database
npm run db:push

# Seed data awal
npm run db:seed
```

### 4. Run Development Server

```bash
npm run dev
```

Buka http://localhost:3000

## Default Login

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@krearte.id | krearte123 |
| CS Agent | cs1@krearte.id | agent123 |
| Designer | designer@krearte.id | designer123 |

## Project Structure

```
krearte-platform/
├── prisma/
│   ├── schema.prisma      # Database schema
│   └── seed.ts            # Seed data
├── src/
│   ├── app/
│   │   ├── (auth)/        # Login pages
│   │   ├── (dashboard)/   # Dashboard pages
│   │   └── api/           # API routes
│   ├── components/
│   │   └── ui/            # UI components
│   ├── lib/
│   │   ├── auth.ts        # NextAuth config
│   │   ├── db.ts          # Prisma client
│   │   └── utils.ts       # Utilities
│   ├── services/
│   │   ├── whatsapp.service.ts    # WhatsApp API
│   │   ├── chatbot.service.ts     # AI Chatbot + RAG
│   │   ├── assignment.service.ts  # CS Assignment
│   │   ├── workflow.service.ts    # n8n Integration
│   │   ├── notification.service.ts
│   │   └── conversation.service.ts
│   └── types/
│       └── index.ts       # TypeScript types
├── .env.example
├── package.json
└── README.md
```

## API Endpoints

### Webhooks

- `POST /api/webhooks/whatsapp` - WhatsApp incoming messages
- `POST /api/webhooks/n8n` - n8n workflow callbacks

### Conversations

- `GET /api/conversations` - List conversations
- `GET /api/conversations/:id` - Get conversation detail
- `PATCH /api/conversations/:id` - Update (assign, resolve)
- `POST /api/conversations/:id/messages` - Send message

### Dashboard

- `GET /api/dashboard` - Dashboard statistics

## WhatsApp Setup

1. Buat Meta Business Account di business.facebook.com
2. Daftarkan WhatsApp Business di developers.facebook.com
3. Buat System User dan generate Permanent Token
4. Setup Webhook dengan URL: `https://your-domain.com/api/webhooks/whatsapp`
5. Subscribe ke messages webhook

## n8n Integration

Platform ini menggunakan n8n untuk workflow automation:

- Design Request Flow
- Sales Order Flow
- Payment Tracking
- Follow-up Automation

Setup n8n:

```bash
docker run -d --name n8n -p 5678:5678 n8nio/n8n
```

## Features

### ✅ Implemented

- [x] WhatsApp webhook integration
- [x] AI Chatbot with RAG
- [x] Automatic CS assignment
- [x] Real-time dashboard
- [x] Conversation management
- [x] Customer management
- [x] Knowledge base
- [x] Product catalog
- [x] Audit logging

### 🚧 Coming Soon

- [ ] Deal pipeline
- [ ] Quotation generation
- [ ] Design request workflow
- [ ] Sales order management
- [ ] Accurate integration
- [ ] Payment tracking
- [ ] Analytics & reports

## License

Proprietary - CV Krearte Mitra Artisan

## Support

Untuk pertanyaan dan support, hubungi tim IT Krearte.
