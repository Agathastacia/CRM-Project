import db from '@/lib/db';
import log from '@/lib/logger';
import whatsappService from './whatsapp.service';
import chatbotService from './chatbot.service';
import assignmentService from './assignment.service';
import notificationService from './notification.service';
import type { WhatsAppMessage } from '@/types';
import type { Customer, Conversation, Message, SenderType, ContentType, WaStatus } from '@prisma/client';

class ConversationService {
  /**
   * Handle incoming WhatsApp message
   */
  async handleIncomingMessage(
    waMessage: WhatsAppMessage,
    senderPhone: string,
    senderName?: string
  ): Promise<void> {
    try {
      // Mark as read
      await whatsappService.markAsRead(waMessage.id);

      // Get or create customer
      const customer = await this.getOrCreateCustomer(senderPhone, senderName);

      // Get or create active conversation
      const conversation = await this.getOrCreateConversation(customer.id);

      // Parse message content
      const { content, contentType, mediaUrl, mediaMimeType, mediaFilename } = 
        await this.parseWhatsAppMessage(waMessage);

      // Save message
      const message = await this.saveMessage(conversation.id, {
        senderType: 'CUSTOMER',
        senderId: customer.id,
        content,
        contentType,
        mediaUrl,
        mediaMimeType,
        mediaFilename,
        waMessageId: waMessage.id,
        waTimestamp: new Date(parseInt(waMessage.timestamp) * 1000),
      });

      // Update conversation
      await db.conversation.update({
        where: { id: conversation.id },
        data: { lastMessageAt: new Date() },
      });

      // Handle based on conversation status
      await this.routeMessage(conversation, customer, message);

      log.info('Incoming message processed', {
        conversationId: conversation.id,
        messageId: message.id,
        status: conversation.status,
      });

    } catch (error) {
      log.error('Handle incoming message error', { error, waMessageId: waMessage.id });
    }
  }

  /**
   * Route message based on conversation status
   */
  private async routeMessage(
    conversation: Conversation,
    customer: Customer,
    message: Message
  ): Promise<void> {
    switch (conversation.status) {
      case 'BOT_HANDLING':
        await this.handleBotConversation(conversation, customer, message);
        break;

      case 'WAITING_ASSIGNMENT':
        // Already waiting, just notify
        log.info('Message received while waiting assignment', { conversationId: conversation.id });
        break;

      case 'AGENT_HANDLING':
      case 'WAITING_CUSTOMER':
        // Update status and notify agent via Socket.IO (handled in webhook)
        await db.conversation.update({
          where: { id: conversation.id },
          data: { status: 'AGENT_HANDLING' },
        });
        break;

      case 'RESOLVED':
      case 'EXPIRED':
        // Reopen conversation with bot
        await db.conversation.update({
          where: { id: conversation.id },
          data: { status: 'BOT_HANDLING' },
        });
        await this.handleBotConversation(conversation, customer, message);
        break;
    }
  }

  /**
   * Handle conversation with AI bot
   */
  private async handleBotConversation(
    conversation: Conversation,
    customer: Customer,
    message: Message
  ): Promise<void> {
    try {
      // Get conversation history
      const messages = await db.message.findMany({
        where: { conversationId: conversation.id },
        orderBy: { createdAt: 'asc' },
        take: 20,
      });

      // Check if this is first message (welcome)
      if (messages.length === 1) {
        const welcomeMessage = await chatbotService.generateWelcome(customer);
        await this.sendBotMessage(conversation.id, customer.phone, welcomeMessage);
        return;
      }

      // Generate bot response
      const response = await chatbotService.generateResponse(
        conversation,
        customer,
        messages,
        message.content
      );

      // Send bot response
      await this.sendBotMessage(conversation.id, customer.phone, response.message);

      // Update collected data
      if (Object.keys(response.collectedData).length > 0) {
        const existingData = (conversation.botCollectedData as Record<string, unknown>) || {};
        await db.conversation.update({
          where: { id: conversation.id },
          data: {
            botCollectedData: { ...existingData, ...response.collectedData },
          },
        });

        // Also update customer if we got new info
        await this.updateCustomerFromCollectedData(customer.id, response.collectedData as Record<string, unknown>);
      }

      // Check for handoff
      if (response.handoff) {
        await this.initiateHandoff(conversation, customer, response.handoffReason);
      }

    } catch (error) {
      log.error('Bot conversation error', { conversationId: conversation.id, error });
      
      // Fallback - handoff to human
      await this.initiateHandoff(conversation, customer, 'Bot error - fallback');
    }
  }

  /**
   * Initiate handoff to human agent
   */
  private async initiateHandoff(
    conversation: Conversation,
    customer: Customer,
    reason?: string
  ): Promise<void> {
    // Update status
    await db.conversation.update({
      where: { id: conversation.id },
      data: { status: 'WAITING_ASSIGNMENT' },
    });

    // Try auto-assign
    const agentId = await assignmentService.autoAssign(conversation.id);

    if (agentId) {
      // Get agent info
      const agent = await db.user.findUnique({ where: { id: agentId } });
      
      // Notify customer
      await this.sendBotMessage(
        conversation.id,
        customer.phone,
        `Baik, saya akan menghubungkan Anda dengan tim kami.\n\n*${agent?.name}* akan segera membantu Anda. Mohon tunggu sebentar ya! 🙏`
      );

      // Notify agent
      await notificationService.notifyAgentNewAssignment(
        agentId,
        customer.name || customer.phone,
        conversation.id
      );

    } else {
      // No available agent
      await this.sendBotMessage(
        conversation.id,
        customer.phone,
        `Terima kasih! 🙏\n\nSaat ini semua tim kami sedang melayani customer lain.\n\nPesan Anda sudah kami terima dan akan segera direspon.\n\nMohon kesabarannya ya! 😊`
      );

      // Notify team via Telegram
      await notificationService.send(
        'TEAM',
        'team',
        'TELEGRAM',
        `⚠️ <b>Waiting Assignment</b>\n\nCustomer: ${customer.name || customer.phone}\nReason: ${reason || 'Customer ready'}\n\nTidak ada agent tersedia!`,
        {}
      );
    }

    log.info('Handoff initiated', {
      conversationId: conversation.id,
      agentId,
      reason,
    });
  }

  /**
   * Send message from agent
   */
  async sendAgentMessage(
    conversationId: string,
    agentId: string,
    content: string,
    contentType: ContentType = 'TEXT'
  ): Promise<Message | null> {
    try {
      const conversation = await db.conversation.findUnique({
        where: { id: conversationId },
        include: { customer: true },
      });

      if (!conversation) return null;

      // Send via WhatsApp
      const waMessageId = await whatsappService.sendText(conversation.customer.phone, content);

      // Save message
      const message = await this.saveMessage(conversationId, {
        senderType: 'AGENT',
        senderId: agentId,
        content,
        contentType,
        waMessageId,
        waStatus: waMessageId ? 'SENT' : 'FAILED',
      });

      // Update conversation
      await db.conversation.update({
        where: { id: conversationId },
        data: {
          status: 'WAITING_CUSTOMER',
          lastMessageAt: new Date(),
          firstResponseAt: conversation.firstResponseAt || new Date(),
        },
      });

      return message;

    } catch (error) {
      log.error('Send agent message error', { conversationId, agentId, error });
      return null;
    }
  }

  /**
   * Send message from bot
   */
  private async sendBotMessage(
    conversationId: string,
    customerPhone: string,
    content: string
  ): Promise<Message | null> {
    try {
      const waMessageId = await whatsappService.sendText(customerPhone, content);

      return this.saveMessage(conversationId, {
        senderType: 'BOT',
        content,
        contentType: 'TEXT',
        waMessageId,
        waStatus: waMessageId ? 'SENT' : 'FAILED',
      });

    } catch (error) {
      log.error('Send bot message error', { conversationId, error });
      return null;
    }
  }

  /**
   * Save message to database
   */
  private async saveMessage(
    conversationId: string,
    data: {
      senderType: SenderType;
      senderId?: string;
      content: string;
      contentType: ContentType;
      mediaUrl?: string | null;
      mediaMimeType?: string | null;
      mediaFilename?: string | null;
      waMessageId?: string | null;
      waTimestamp?: Date;
      waStatus?: WaStatus;
    }
  ): Promise<Message> {
    return db.message.create({
      data: {
        conversationId,
        ...data,
        waStatus: data.waStatus || 'PENDING',
      },
    });
  }

  /**
   * Get or create customer
   */
  private async getOrCreateCustomer(phone: string, name?: string): Promise<Customer> {
    let customer = await db.customer.findUnique({ where: { phone } });

    if (!customer) {
      customer = await db.customer.create({
        data: {
          phone,
          name,
          category: 'UNKNOWN',
        },
      });
      log.info('New customer created', { customerId: customer.id, phone });
    } else if (name && !customer.name) {
      customer = await db.customer.update({
        where: { id: customer.id },
        data: { name },
      });
    }

    // Update last interaction
    await db.customer.update({
      where: { id: customer.id },
      data: { lastInteractionAt: new Date() },
    });

    return customer;
  }

  /**
   * Get or create active conversation
   */
  private async getOrCreateConversation(customerId: string): Promise<Conversation> {
    // Look for active conversation (not resolved/expired in last 24h)
    const activeConversation = await db.conversation.findFirst({
      where: {
        customerId,
        status: {
          notIn: ['RESOLVED', 'EXPIRED'],
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    if (activeConversation) {
      return activeConversation;
    }

    // Check if there's a recent resolved conversation (within 24h)
    const recentResolved = await db.conversation.findFirst({
      where: {
        customerId,
        status: { in: ['RESOLVED', 'EXPIRED'] },
        resolvedAt: {
          gte: new Date(Date.now() - 24 * 60 * 60 * 1000),
        },
      },
      orderBy: { resolvedAt: 'desc' },
    });

    if (recentResolved) {
      // Reopen
      return db.conversation.update({
        where: { id: recentResolved.id },
        data: { status: 'BOT_HANDLING' },
      });
    }

    // Create new
    return db.conversation.create({
      data: {
        customerId,
        status: 'BOT_HANDLING',
        channel: 'whatsapp',
      },
    });
  }

  /**
   * Parse WhatsApp message content
   */
  private async parseWhatsAppMessage(waMessage: WhatsAppMessage): Promise<{
    content: string;
    contentType: ContentType;
    mediaUrl?: string;
    mediaMimeType?: string;
    mediaFilename?: string;
  }> {
    switch (waMessage.type) {
      case 'text':
        return {
          content: waMessage.text?.body || '',
          contentType: 'TEXT',
        };

      case 'image':
        return {
          content: waMessage.image?.caption || '[Image]',
          contentType: 'IMAGE',
          mediaMimeType: waMessage.image?.mime_type,
        };

      case 'document':
        return {
          content: waMessage.document?.caption || `[Document: ${waMessage.document?.filename}]`,
          contentType: 'DOCUMENT',
          mediaMimeType: waMessage.document?.mime_type,
          mediaFilename: waMessage.document?.filename,
        };

      case 'audio':
        return {
          content: '[Voice Message]',
          contentType: 'AUDIO',
          mediaMimeType: waMessage.audio?.mime_type,
        };

      case 'video':
        return {
          content: waMessage.video?.caption || '[Video]',
          contentType: 'VIDEO',
          mediaMimeType: waMessage.video?.mime_type,
        };

      case 'location':
        return {
          content: `[Location: ${waMessage.location?.name || ''} - ${waMessage.location?.address || `${waMessage.location?.latitude}, ${waMessage.location?.longitude}`}]`,
          contentType: 'LOCATION',
        };

      case 'interactive':
        const interactiveContent = 
          waMessage.interactive?.button_reply?.title ||
          waMessage.interactive?.list_reply?.title ||
          '[Interactive Response]';
        return {
          content: interactiveContent,
          contentType: 'INTERACTIVE',
        };

      default:
        return {
          content: `[${waMessage.type}]`,
          contentType: 'TEXT',
        };
    }
  }

  /**
   * Update customer from collected data
   */
  private async updateCustomerFromCollectedData(
    customerId: string,
    data: Record<string, unknown>
  ): Promise<void> {
    const updates: Record<string, unknown> = {};

    if (data.name && typeof data.name === 'string') {
      updates.name = data.name;
    }
    if (data.location && typeof data.location === 'string') {
      updates.city = data.location;
    }
    if (data.category && typeof data.category === 'string') {
      const categoryMap: Record<string, string> = {
        'retail': 'RETAIL',
        'end user': 'RETAIL',
        'designer': 'DESIGNER',
        'interior': 'DESIGNER',
        'arsitek': 'DESIGNER',
        'reseller': 'RESELLER',
        'toko': 'RESELLER',
      };
      const category = categoryMap[data.category.toLowerCase()];
      if (category) {
        updates.category = category;
      }
    }

    if (Object.keys(updates).length > 0) {
      await db.customer.update({
        where: { id: customerId },
        data: updates,
      });
    }
  }

  /**
   * Resolve conversation
   */
  async resolveConversation(conversationId: string, summary?: string): Promise<void> {
    const conversation = await db.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) return;

    await db.conversation.update({
      where: { id: conversationId },
      data: {
        status: 'RESOLVED',
        resolvedAt: new Date(),
        summary,
      },
    });

    // Release agent load
    if (conversation.agentId) {
      await assignmentService.releaseConversation(conversationId, conversation.agentId);
    }

    log.info('Conversation resolved', { conversationId });
  }
}

export const conversationService = new ConversationService();
export default conversationService;
