'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Filter, RefreshCw, Plus, Edit, Trash2, X } from 'lucide-react';
import { formatDate, formatAmount, parseAmount } from '@/lib/utils';

interface Customer {
  id: string;
  name: string | null;
  phone: string;
}

interface Deal {
  id: string;
  title: string;
}

interface Order {
  id: string;
  customerId: string;
  dealId: string | null;
  orderNumber: string;
  status: string;
  paymentStatus: string;
  totalAmount: number | null;
  shippingAddress: string | null;
  notes: string | null;
  createdAt: string;
  customer: Customer;
  deal: Deal | null;
}

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [newOrder, setNewOrder] = useState({
    customerId: '',
    dealId: '',
    orderNumber: `ORD-${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 12)}`,
    status: 'PENDING',
    paymentStatus: 'UNPAID',
    totalAmount: '',
    shippingAddress: '',
    notes: ''
  });
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);

  useEffect(() => {
    fetchOrders();
    fetchCustomers();
    fetchDeals();
  }, [searchQuery, selectedStatus]);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.set('q', searchQuery);
      if (selectedStatus) params.set('status', selectedStatus);
      
      const res = await fetch(`/api/orders?${params}`);
      const data = await res.json();
      if (data.success) {
        setOrders(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomers = async () => {
    try {
      const res = await fetch('/api/customers');
      const data = await res.json();
      if (data.success) {
        setCustomers(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch customers:', error);
    }
  };

  const fetchDeals = async () => {
    try {
      const res = await fetch('/api/deals');
      const data = await res.json();
      if (data.success) {
        setDeals(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch deals:', error);
    }
  };

  // Handle Add Order
  const handleAddOrder = async () => {
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder)
      });
      
      const data = await res.json();
      if (data.success) {
        fetchOrders();
        setShowAddForm(false);
        setNewOrder({
          customerId: '',
          dealId: '',
          orderNumber: `ORD-${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 12)}`,
          status: 'PENDING',
          paymentStatus: 'UNPAID',
          totalAmount: '',
          shippingAddress: '',
          notes: ''
        });
      }
    } catch (error) {
      console.error('Failed to add order:', error);
    }
  };

  // Handle Edit Order
  const handleEditOrder = (order: Order) => {
    setEditingOrder(order);
    setNewOrder({
      customerId: order.customerId,
      dealId: order.dealId || '',
      orderNumber: order.orderNumber,
      status: order.status,
      paymentStatus: order.paymentStatus,
      totalAmount: order.totalAmount?.toString() || '',
      shippingAddress: order.shippingAddress || '',
      notes: order.notes || ''
    });
    setShowEditForm(true);
  };

  const handleUpdateOrder = async () => {
    if (!editingOrder) return;

    try {
      const res = await fetch(`/api/orders/${editingOrder.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder)
      });
      
      const data = await res.json();
      if (data.success) {
        fetchOrders();
        setShowEditForm(false);
        setEditingOrder(null);
        setNewOrder({
          customerId: '',
          dealId: '',
          orderNumber: `ORD-${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 12)}`,
          status: 'PENDING',
          paymentStatus: 'UNPAID',
          totalAmount: '',
          shippingAddress: '',
          notes: ''
        });
      }
    } catch (error) {
      console.error('Failed to update order:', error);
    }
  };

  // Handle Delete Order
  const handleDeleteOrder = async (orderId: string) => {
    if (!confirm('Yakin ingin menghapus order ini?')) return;

    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'DELETE'
      });
      
      const data = await res.json();
      if (data.success) {
        fetchOrders();
      }
    } catch (error) {
      console.error('Failed to delete order:', error);
    }
  };

  const statusOptions = [
    { value: '', label: 'Semua Status' },
    { value: 'PENDING', label: 'Pending', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'PROCESSING', label: 'Processing', color: 'bg-blue-100 text-blue-800' },
    { value: 'SHIPPED', label: 'Shipped', color: 'bg-purple-100 text-purple-800' },
    { value: 'DELIVERED', label: 'Delivered', color: 'bg-green-100 text-green-800' },
    { value: 'CANCELLED', label: 'Cancelled', color: 'bg-red-100 text-red-800' },
  ];

  const paymentStatusOptions = [
    { value: 'UNPAID', label: 'Unpaid', color: 'bg-red-100 text-red-800' },
    { value: 'PAID', label: 'Paid', color: 'bg-green-100 text-green-800' },
    { value: 'REFUNDED', label: 'Refunded', color: 'bg-gray-100 text-gray-800' },
  ];

  const filteredOrders = (orders || []).filter((order) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      order.orderNumber.toLowerCase().includes(q) ||
      order.customer.name?.toLowerCase().includes(q) ||
      order.customer.phone.includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Orders</h1>
          <p className="text-muted-foreground">Kelola pesanan produk</p>
        </div>
        <Button onClick={() => setShowAddForm(!showAddForm)}>
          <Plus className="h-4 w-4 mr-2" /> Tambah Order
        </Button>
      </div>

      {/* Form Tambah/Edit Order */}
      {(showAddForm || showEditForm) && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>
              {showEditForm ? 'Edit Order' : 'Tambah Order Baru'}
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingOrder(null);
                setNewOrder({
                  customerId: '',
                  dealId: '',
                  orderNumber: `ORD-${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 12)}`,
                  status: 'PENDING',
                  paymentStatus: 'UNPAID',
                  totalAmount: '',
                  shippingAddress: '',
                  notes: ''
                });
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Customer</label>
                <select
                  value={newOrder.customerId}
                  onChange={(e) => setNewOrder({...newOrder, customerId: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                  required
                >
                  <option value="">Pilih Customer</option>
                  {customers.map((customer) => (
                    <option key={customer.id} value={customer.id}>
                      {customer.name || customer.phone}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Deal (Opsional)</label>
                <select
                  value={newOrder.dealId}
                  onChange={(e) => setNewOrder({...newOrder, dealId: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                >
                  <option value="">Tidak ada deal</option>
                  {deals.map((deal) => (
                    <option key={deal.id} value={deal.id}>
                      {deal.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Order Number</label>
                <Input
                  value={newOrder.orderNumber}
                  onChange={(e) => setNewOrder({...newOrder, orderNumber: e.target.value})}
                  placeholder="Contoh: ORD-2026-001"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium">Status</label>
                <select
                  value={newOrder.status}
                  onChange={(e) => setNewOrder({...newOrder, status: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                >
                  {statusOptions.filter(opt => opt.value).map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Payment Status</label>
                <select
                  value={newOrder.paymentStatus}
                  onChange={(e) => setNewOrder({...newOrder, paymentStatus: e.target.value})}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                >
                  {paymentStatusOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Total Amount (Rp)</label>
                <Input
                  type="text"
                  value={newOrder.totalAmount}
                  onChange={(e) => {
                    const value = e.target.value.replace(/[^0-9,]/g, '');
                    setNewOrder({...newOrder, totalAmount: value});
                  }}
                  placeholder="Contoh: 5.000.000"
                  className="text-right"
                />
                {newOrder.totalAmount && (
                  <p className="text-xs text-muted-foreground mt-1 text-right">
                    Rp {formatAmount(parseAmount(newOrder.totalAmount))}
                  </p>
                )}
              </div>
              <div className="md:col-span-2">
                <label className="text-sm font-medium">Shipping Address</label>
                <Input
                  value={newOrder.shippingAddress}
                  onChange={(e) => setNewOrder({...newOrder, shippingAddress: e.target.value})}
                  placeholder="Alamat pengiriman"
                />
              </div>
              <div className="md:col-span-2">
                <label className="text-sm font-medium">Notes</label>
                <Input
                  value={newOrder.notes}
                  onChange={(e) => setNewOrder({...newOrder, notes: e.target.value})}
                  placeholder="Catatan tambahan"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => {
                setShowAddForm(false);
                setShowEditForm(false);
                setEditingOrder(null);
                setNewOrder({
                  customerId: '',
                  dealId: '',
                  orderNumber: `ORD-${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 12)}`,
                  status: 'PENDING',
                  paymentStatus: 'UNPAID',
                  totalAmount: '',
                  shippingAddress: '',
                  notes: ''
                });
              }}>Batal</Button>
              <Button onClick={showEditForm ? handleUpdateOrder : handleAddOrder}>
                {showEditForm ? 'Update Order' : 'Simpan Order'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari order..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="h-10 px-3 rounded-md border border-input bg-background text-sm"
            >
              {statusOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <Button variant="outline" size="sm" onClick={fetchOrders}>
              <RefreshCw className="h-4 w-4 mr-2" /> Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📦</div>
              <h3 className="text-xl font-semibold">Tidak ada order</h3>
              <p className="text-muted-foreground mt-2">Mulailah dengan menambahkan order pertama Anda</p>
              <Button className="mt-4" size="lg" onClick={() => setShowAddForm(true)}>
                <Plus className="h-4 w-4 mr-2" /> Tambah Order
              </Button>
            </div>
          ) : (
            <div className="divide-y">
              {filteredOrders.map((order) => (
                <div key={order.id} className="flex items-center gap-4 py-4 hover:bg-muted/50 px-2 -mx-2 rounded-lg transition-colors">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      📦
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold">{order.orderNumber}</span>
                      <span className={`px-2 py-0.5 text-xs rounded-full ${statusOptions.find(opt => opt.value === order.status)?.color || 'bg-gray-100'}`}>
                        {statusOptions.find(opt => opt.value === order.status)?.label || order.status}
                      </span>
                      <span className={`px-2 py-0.5 text-xs rounded-full ${paymentStatusOptions.find(opt => opt.value === order.paymentStatus)?.color || 'bg-gray-100'}`}>
                        {paymentStatusOptions.find(opt => opt.value === order.paymentStatus)?.label || order.paymentStatus}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>Customer: {order.customer.name || order.customer.phone}</span>
                      {order.totalAmount && <span>• Rp {formatAmount(order.totalAmount)}</span>}
                      {order.deal && <span>• Deal: {order.deal.title}</span>}
                    </div>
                    {order.shippingAddress && (
                      <p className="text-xs mt-1 text-muted-foreground">
                        📍 {order.shippingAddress}
                      </p>
                    )}
                    {order.notes && (
                      <p className="text-xs mt-1 text-muted-foreground">
                        📝 {order.notes}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Edit"
                      onClick={() => handleEditOrder(order)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      title="Hapus"
                      onClick={() => handleDeleteOrder(order.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}