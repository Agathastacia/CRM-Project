'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Search, Filter, RefreshCw } from 'lucide-react';
import { getInitials, truncate, formatDate } from '@/lib/utils';

interface Conversation {
  id: string;
  status: string;
  priority: string;
  lastMessageAt: string;
  createdAt: string;
  customer: {
    id: string;
    name: string | null;
    phone: string;
    category: string;
  };
  agent: { id: string; name: string } | null;
  messages: Array<{ content: string; senderType: string }>;
}

const statusOptions = [
  { value: '', label: 'Semua Status' },
  { value: 'WAITING_ASSIGNMENT', label: 'Menunggu' },
  { value: 'BOT_HANDLING', label: 'Bot' },
  { value: 'AGENT_HANDLING', label: 'Agent' },
  { value: 'WAITING_CUSTOMER', label: 'Tunggu Reply' },
  { value: 'RESOLVED', label: 'Selesai' },
];

export default function ConversationsPage() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchConversations();
  }, [statusFilter]);

  const fetchConversations = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter) params.set('status', statusFilter);
      const res = await fetch(`/api/conversations?${params}`);
      const data = await res.json();
      if (data.success) {
        setConversations(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const config: Record<string, { label: string; className: string }> = {
      WAITING_ASSIGNMENT: { label: 'Menunggu', className: 'bg-yellow-100 text-yellow-800' },
      BOT_HANDLING: { label: 'Bot', className: 'bg-gray-100 text-gray-800' },
      AGENT_HANDLING: { label: 'Agent', className: 'bg-blue-100 text-blue-800' },
      WAITING_CUSTOMER: { label: 'Tunggu Reply', className: 'bg-purple-100 text-purple-800' },
      RESOLVED: { label: 'Selesai', className: 'bg-green-100 text-green-800' },
    };
    const c = config[status] || { label: status, className: 'bg-gray-100' };
    return <span className={`px-2 py-1 rounded-full text-xs font-medium ${c.className}`}>{c.label}</span>;
  };

  const filteredConversations = conversations.filter((conv) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      conv.customer.name?.toLowerCase().includes(q) ||
      conv.customer.phone.includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Conversations</h1>
          <p className="text-muted-foreground">Kelola semua percakapan dengan pelanggan</p>
        </div>
        <Button onClick={fetchConversations} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Cari nama atau nomor..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="h-10 px-3 rounded-md border border-input bg-background text-sm"
            >
              {statusOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredConversations.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Tidak ada percakapan</p>
          ) : (
            <div className="divide-y">
              {filteredConversations.map((conv) => (
                <Link
                  key={conv.id}
                  href={`/dashboard/conversations/${conv.id}`}
                  className="flex items-center gap-4 py-4 hover:bg-muted/50 px-2 -mx-2 rounded-lg transition-colors"
                >
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="text-lg">
                      {getInitials(conv.customer.name || conv.customer.phone)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-semibold">{conv.customer.name || conv.customer.phone}</span>
                      {getStatusBadge(conv.status)}
                      {conv.priority === 'HIGH' && (
                        <Badge variant="destructive" className="text-xs">Urgent</Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      {conv.messages[0]?.content ? truncate(conv.messages[0].content, 60) : 'Belum ada pesan'}
                    </p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <span>{conv.customer.phone}</span>
                      {conv.agent && <span>• {conv.agent.name}</span>}
                      <span>• {formatDate(conv.lastMessageAt || conv.createdAt)}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
