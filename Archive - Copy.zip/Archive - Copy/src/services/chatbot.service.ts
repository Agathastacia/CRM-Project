import Anthropic from '@anthropic-ai/sdk';
import db from '@/lib/db';
import log from '@/lib/logger';
import type { Customer, Message, Conversation } from '@prisma/client';
import type { ChatbotResponse, BotCollectedData } from '@/types';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const MODEL = process.env.ANTHROPIC_MODEL || 'claude-3-5-sonnet-20241022';

const SYSTEM_PROMPT = `Kamu adalah asisten virtual Krearte Mitra Artisan, perusahaan custom wallcovering dan wallpaper printing di Surabaya.

IDENTITAS:
- Nama: Asisten Krearte
- Bahasa: Bahasa Indonesia yang ramah, sopan, dan professional
- Gaya: Friendly tapi tetap profesional, gunakan emoji secukupnya

KEMAMPUAN:
- Menjawab pertanyaan tentang produk, harga, dan layanan Krearte
- Memberikan informasi material wallcovering (PVC, fabric-back, non-woven, dll)
- Memberikan estimasi harga berdasarkan kategori customer
- Mengumpulkan informasi untuk pemesanan

BATASAN PENTING:
- SELALU gunakan data harga dari knowledge base, JANGAN buat harga sendiri
- JANGAN menjanjikan diskon tanpa konfirmasi tim
- Jika tidak yakin atau info tidak ada, katakan akan dikonfirmasi oleh CS

KATEGORI HARGA:
- Retail: Customer end-user / individual
- Designer: Interior designer, arsitek
- Reseller: Toko, distributor

FLOW PERCAKAPAN:
1. Sapa dengan ramah
2. Tanyakan kebutuhan
3. Berikan info relevan dari knowledge base
4. Jika customer tertarik, kumpulkan:
   - Nama lengkap
   - Material yang diinginkan
   - Ukuran area (m2)
   - Lokasi (kota)
   - Kategori (end user/designer/reseller)
5. Setelah info cukup → handoff ke CS

HANDOFF KE CS MANUSIA jika:
- Customer sudah siap order (info lengkap)
- Pertanyaan kompleks butuh konfirmasi
- Customer minta bicara dengan CS
- Sudah 5+ interaksi tanpa progress
- Customer komplain atau marah

FORMAT OUTPUT:
Selalu respond dalam JSON:
{
  "message": "pesan untuk customer",
  "handoff": true/false,
  "handoffReason": "alasan (jika handoff)",
  "collectedData": {
    "name": "nama",
    "needs": "kebutuhan",
    "material": "jenis material",
    "size": "ukuran m2",
    "location": "kota",
    "category": "retail/designer/reseller",
    "budget": "range budget",
    "notes": "catatan lain"
  }
}`;

class ChatbotService {
  /**
   * Generate response for incoming message
   */
  async generateResponse(
    conversation: Conversation,
    customer: Customer,
    messages: Message[],
    currentMessage: string
  ): Promise<ChatbotResponse> {
    try {
      // Search knowledge base for context
      const context = await this.searchContext(currentMessage);

      // Build conversation history
      const history = this.buildHistory(messages);

      // Add context to current message
      const contextualMessage = context
        ? `[KNOWLEDGE BASE]\n${context}\n\n[PESAN CUSTOMER]\n${currentMessage}`
        : currentMessage;

      // Customer info
      const customerInfo = `
[INFO CUSTOMER]
Nama: ${customer.name || 'Belum diketahui'}
Telepon: ${customer.phone}
Kategori: ${customer.category || 'UNKNOWN'}
Perusahaan: ${customer.companyName || '-'}
Kota: ${customer.city || '-'}
`;

      // Call Claude API
      const response = await anthropic.messages.create({
        model: MODEL,
        max_tokens: 1024,
        system: SYSTEM_PROMPT + '\n\n' + customerInfo,
        messages: [
          ...history,
          { role: 'user', content: contextualMessage },
        ],
      });

      const content = response.content[0]?.type === 'text' 
        ? response.content[0].text 
        : '';

      log.ai('Claude response', {
        conversationId: conversation.id,
        inputTokens: response.usage?.input_tokens,
        outputTokens: response.usage?.output_tokens,
      });

      // Parse response
      return this.parseResponse(content, messages.length);

    } catch (error) {
      log.error('Chatbot error', { error });
      
      return {
        message: 'Mohon maaf, terjadi gangguan. Tim kami akan segera membantu Anda. 🙏',
        handoff: true,
        handoffReason: 'AI error - fallback to human',
        collectedData: {},
      };
    }
  }

  /**
   * Search knowledge base and products for context
   */
  private async searchContext(query: string): Promise<string> {
    let context = '';

    try {
      // Search knowledge base
      const knowledge = await db.$queryRaw<Array<{ title: string; content: string }>>`
        SELECT title, content FROM knowledge_base 
        WHERE is_active = 1 
        AND MATCH(title, content) AGAINST(${query} IN NATURAL LANGUAGE MODE)
        LIMIT 3
      `;

      if (knowledge.length > 0) {
        context += '=== INFORMASI ===\n';
        knowledge.forEach((kb, i) => {
          context += `[${i + 1}] ${kb.title}\n${kb.content}\n\n`;
        });
      }

      // Search products
      const products = await db.$queryRaw<Array<{
        name: string;
        category: string;
        material_type: string;
        price_retail: number;
        price_designer: number;
        price_reseller: number;
      }>>`
        SELECT name, category, material_type, price_retail, price_designer, price_reseller
        FROM products 
        WHERE is_active = 1 
        AND MATCH(name, description, material_type) AGAINST(${query} IN NATURAL LANGUAGE MODE)
        LIMIT 5
      `;

      if (products.length > 0) {
        context += '=== PRODUK TERKAIT ===\n';
        products.forEach((p, i) => {
          context += `[${i + 1}] ${p.name}\n`;
          context += `   Kategori: ${p.category}\n`;
          context += `   Material: ${p.material_type || '-'}\n`;
          context += `   Harga Retail: Rp ${p.price_retail?.toLocaleString('id-ID')}/m2\n`;
          context += `   Harga Designer: Rp ${p.price_designer?.toLocaleString('id-ID')}/m2\n`;
          context += `   Harga Reseller: Rp ${p.price_reseller?.toLocaleString('id-ID')}/m2\n\n`;
        });
      }

      // If fulltext search returns nothing, try LIKE
      if (!context) {
        const keywords = query.toLowerCase().split(' ').filter(w => w.length > 2);
        if (keywords.length > 0) {
          const term = `%${keywords[0]}%`;
          
          const fallbackKb = await db.knowledgeBase.findMany({
            where: {
              isActive: true,
              OR: [
                { title: { contains: keywords[0] } },
                { content: { contains: keywords[0] } },
              ],
            },
            take: 3,
          });

          if (fallbackKb.length > 0) {
            context += '=== INFORMASI ===\n';
            fallbackKb.forEach((kb, i) => {
              context += `[${i + 1}] ${kb.title}\n${kb.content}\n\n`;
            });
          }
        }
      }

    } catch (error) {
      log.error('Context search error', { error });
    }

    return context;
  }

  /**
   * Build message history for Claude
   */
  private buildHistory(messages: Message[]): Array<{ role: 'user' | 'assistant'; content: string }> {
    const history: Array<{ role: 'user' | 'assistant'; content: string }> = [];

    // Take last 10 messages for context
    const recentMessages = messages.slice(-10);

    for (const msg of recentMessages) {
      if (msg.senderType === 'CUSTOMER') {
        history.push({ role: 'user', content: msg.content });
      } else if (msg.senderType === 'BOT') {
        history.push({ role: 'assistant', content: msg.content });
      }
    }

    return history;
  }

  /**
   * Parse Claude response
   */
  private parseResponse(content: string, messageCount: number): ChatbotResponse {
    try {
      // Try to find JSON in response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          message: parsed.message || content,
          handoff: parsed.handoff || false,
          handoffReason: parsed.handoffReason,
          handoffMessage: parsed.handoff ? parsed.message : undefined,
          collectedData: parsed.collectedData || {},
        };
      }
    } catch {
      // Not valid JSON, continue
    }

    // Check for handoff triggers
    const shouldHandoff = this.checkHandoffTriggers(content, messageCount);

    return {
      message: content,
      handoff: shouldHandoff,
      handoffReason: shouldHandoff ? 'Auto-detected handoff trigger' : undefined,
      collectedData: {},
    };
  }

  /**
   * Check if should handoff to human
   */
  private checkHandoffTriggers(content: string, messageCount: number): boolean {
    const handoffKeywords = [
      'hubungi cs',
      'bicara dengan',
      'tim kami akan',
      'akan dibantu',
      'konfirmasi lebih lanjut',
      'menghubungkan anda',
    ];

    const lower = content.toLowerCase();
    
    for (const keyword of handoffKeywords) {
      if (lower.includes(keyword)) {
        return true;
      }
    }

    // Auto handoff after many messages without resolution
    if (messageCount >= 10) {
      return true;
    }

    return false;
  }

  /**
   * Generate welcome message
   */
  async generateWelcome(customer: Customer): Promise<string> {
    const greeting = customer.name ? `Halo ${customer.name}! 👋` : 'Halo! 👋';

    return `${greeting}

Selamat datang di *Krearte Mitra Artisan* ✨

Kami spesialis custom wallcovering & wallpaper printing untuk interior impian Anda.

Ada yang bisa saya bantu hari ini? 😊

Silakan ceritakan kebutuhan Anda:
• Info Produk & Material
• Estimasi Harga  
• Konsultasi Desain
• Lainnya`;
  }
}

export const chatbotService = new ChatbotService();
export default chatbotService;
