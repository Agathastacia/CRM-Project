import axios from 'axios';
import db from '@/lib/db';
import log from '@/lib/logger';
import whatsappService from './whatsapp.service';
import type { NotificationChannel, NotificationRecipientType } from '@prisma/client';

class NotificationService {
  /**
   * Send notification through specified channel
   */
  async send(
    recipientType: NotificationRecipientType,
    recipientId: string,
    channel: NotificationChannel,
    template: string,
    variables: Record<string, string> = {},
    scheduledAt?: Date
  ): Promise<string | null> {
    try {
      // Create notification record
      const notification = await db.notification.create({
        data: {
          recipientType,
          recipientId,
          channel,
          template,
          variables,
          status: scheduledAt && scheduledAt > new Date() ? 'PENDING' : 'PENDING',
          scheduledAt: scheduledAt || new Date(),
        },
      });

      // If scheduled for later, just return
      if (scheduledAt && scheduledAt > new Date()) {
        log.info('Notification scheduled', { notificationId: notification.id, scheduledAt });
        return notification.id;
      }

      // Send immediately
      await this.processNotification(notification.id);

      return notification.id;

    } catch (error) {
      log.error('Notification send error', { error });
      return null;
    }
  }

  /**
   * Process and send a notification
   */
  async processNotification(notificationId: string): Promise<boolean> {
    try {
      const notification = await db.notification.findUnique({
        where: { id: notificationId },
      });

      if (!notification || notification.status !== 'PENDING') {
        return false;
      }

      // Get recipient contact info
      const recipientInfo = await this.getRecipientInfo(
        notification.recipientType,
        notification.recipientId
      );

      if (!recipientInfo) {
        await this.markFailed(notificationId, 'Recipient not found');
        return false;
      }

      // Render message with variables
      const message = this.renderTemplate(
        notification.template,
        notification.variables as Record<string, string>
      );

      // Send based on channel
      let success = false;
      switch (notification.channel) {
        case 'WHATSAPP':
          success = await this.sendWhatsApp(recipientInfo.phone!, message);
          break;
        case 'EMAIL':
          success = await this.sendEmail(recipientInfo.email!, message, notification.template);
          break;
        case 'TELEGRAM':
          success = await this.sendTelegram(message);
          break;
        default:
          log.warn('Unknown notification channel', { channel: notification.channel });
      }

      if (success) {
        await db.notification.update({
          where: { id: notificationId },
          data: { status: 'SENT', sentAt: new Date() },
        });
      } else {
        await this.markFailed(notificationId, 'Send failed');
      }

      return success;

    } catch (error: any) {
      await this.markFailed(notificationId, error.message);
      return false;
    }
  }

  /**
   * Get recipient contact info
   */
  private async getRecipientInfo(
    type: NotificationRecipientType,
    id: string
  ): Promise<{ phone?: string; email?: string } | null> {
    switch (type) {
      case 'CUSTOMER': {
        const customer = await db.customer.findUnique({
          where: { id },
          select: { phone: true, email: true },
        });
        return customer
          ? { phone: customer.phone, email: customer.email ?? undefined }
          : null;
      }

      case 'AGENT': {
        const agent = await db.user.findUnique({
          where: { id },
          select: { phone: true, email: true },
        });
        return agent
          ? { phone: agent.phone ?? undefined, email: agent.email ?? undefined }
          : null;
      }

      case 'TEAM':
        // Return configured team contact
        return {
          phone: process.env.TEAM_WHATSAPP_NUMBER,
          email: process.env.TEAM_EMAIL,
        };

      default:
        return null;
    }
  }

  /**
   * Render template with variables
   */
  private renderTemplate(template: string, variables: Record<string, string>): string {
    let message = template;
    for (const [key, value] of Object.entries(variables)) {
      message = message.replace(new RegExp(`{{${key}}}`, 'g'), value);
    }
    return message;
  }

  /**
   * Send WhatsApp notification
   */
  private async sendWhatsApp(phone: string, message: string): Promise<boolean> {
    try {
      const messageId = await whatsappService.sendText(phone, message);
      return !!messageId;
    } catch (error) {
      log.error('WhatsApp notification error', { phone, error });
      return false;
    }
  }

  /**
   * Send email notification (placeholder - implement with your SMTP service)
   */
  private async sendEmail(email: string, message: string, subject: string): Promise<boolean> {
    try {
      // TODO: Implement with nodemailer or other email service
      log.info('Email notification (not implemented)', { email, subject });
      return true;
    } catch (error) {
      log.error('Email notification error', { email, error });
      return false;
    }
  }

  /**
   * Send Telegram notification (for internal team)
   */
  private async sendTelegram(message: string): Promise<boolean> {
    try {
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      const chatId = process.env.TELEGRAM_CHAT_ID;

      if (!botToken || !chatId) {
        log.warn('Telegram not configured');
        return false;
      }

      await axios.post(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        chat_id: chatId,
        text: message,
        parse_mode: 'HTML',
      });

      return true;

    } catch (error) {
      log.error('Telegram notification error', { error });
      return false;
    }
  }

  /**
   * Mark notification as failed
   */
  private async markFailed(notificationId: string, errorMessage: string): Promise<void> {
    await db.notification.update({
      where: { id: notificationId },
      data: { status: 'FAILED', errorMessage },
    });
  }

  /**
   * Process pending scheduled notifications (called by cron)
   */
  async processScheduledNotifications(): Promise<number> {
    try {
      const pending = await db.notification.findMany({
        where: {
          status: 'PENDING',
          scheduledAt: { lte: new Date() },
        },
        take: 50,
      });

      let processed = 0;
      for (const notification of pending) {
        const success = await this.processNotification(notification.id);
        if (success) processed++;
      }

      return processed;

    } catch (error) {
      log.error('Process scheduled notifications error', { error });
      return 0;
    }
  }

  // ============================================
  // Pre-built notification templates
  // ============================================

  /**
   * Notify agent of new assignment
   */
  async notifyAgentNewAssignment(
    agentId: string,
    customerName: string,
    conversationId: string
  ): Promise<void> {
    const agent = await db.user.findUnique({ where: { id: agentId } });
    if (!agent) return;

    // Send Telegram to team
    await this.send(
      'TEAM',
      'team',
      'TELEGRAM',
      `🆕 <b>Chat Baru</b>\n\nCustomer: ${customerName}\nAssigned to: ${agent.name}\n\n<a href="${process.env.NEXT_PUBLIC_APP_URL}/conversations/${conversationId}">Buka Chat</a>`,
      {}
    );
  }

  /**
   * Notify customer of CS assignment
   */
  async notifyCustomerAgentAssigned(
    customerId: string,
    phone: string,
    agentName: string
  ): Promise<void> {
    await this.send(
      'CUSTOMER',
      customerId,
      'WHATSAPP',
      `Halo! 👋\n\nTerima kasih sudah menghubungi Krearte.\n\nAnda sekarang terhubung dengan *${agentName}* yang akan membantu Anda.\n\nSilakan sampaikan kebutuhan Anda lebih detail 😊`,
      {}
    );
  }

  /**
   * Payment reminder
   */
  async sendPaymentReminder(
    customerId: string,
    phone: string,
    orderNumber: string,
    total: string,
    dueDate: string
  ): Promise<void> {
    await this.send(
      'CUSTOMER',
      customerId,
      'WHATSAPP',
      `Halo! 👋\n\nIni adalah pengingat untuk pembayaran pesanan Anda:\n\n📋 No. Order: *${orderNumber}*\n💰 Total: *${total}*\n📅 Jatuh Tempo: *${dueDate}*\n\nMohon segera melakukan pembayaran agar pesanan dapat segera diproses.\n\nTerima kasih! 🙏`,
      { orderNumber, total, dueDate }
    );
  }

  /**
   * Design ready for review
   */
  async notifyDesignReady(
    customerId: string,
    phone: string,
    designTitle: string
  ): Promise<void> {
    await this.send(
      'CUSTOMER',
      customerId,
      'WHATSAPP',
      `Halo! 🎨\n\nDesain *${designTitle}* sudah selesai dan siap untuk Anda review.\n\nSilakan cek dan berikan feedback Anda.\n\nTerima kasih! 😊`,
      { designTitle }
    );
  }

  /**
   * Order production complete
   */
  async notifyProductionComplete(
    customerId: string,
    phone: string,
    orderNumber: string
  ): Promise<void> {
    await this.send(
      'CUSTOMER',
      customerId,
      'WHATSAPP',
      `Halo! ✨\n\nPesanan *${orderNumber}* sudah selesai diproduksi dan siap untuk pengiriman/pemasangan.\n\nTim kami akan segera menghubungi untuk mengatur jadwal.\n\nTerima kasih! 🙏`,
      { orderNumber }
    );
  }
}

export const notificationService = new NotificationService();
export default notificationService;
