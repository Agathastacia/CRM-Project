import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import db from '@/lib/db';
import log from '@/lib/logger';

/**
 * GET - Dashboard statistics
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [
      waitingCount,
      activeCount,
      resolvedToday,
      totalCustomers,
      activeDeals,
      availableAgents,
      recentConversations,
    ] = await Promise.all([
      // Waiting assignment
      db.conversation.count({
        where: { status: 'WAITING_ASSIGNMENT' },
      }),

      // Active (bot or agent handling)
      db.conversation.count({
        where: {
          status: { in: ['BOT_HANDLING', 'AGENT_HANDLING', 'WAITING_CUSTOMER'] },
        },
      }),

      // Resolved today
      db.conversation.count({
        where: {
          status: 'RESOLVED',
          resolvedAt: { gte: today },
        },
      }),

      // Total customers
      db.customer.count(),

      // Active deals (not won/lost/cancelled)
      db.deal.count({
        where: {
          stage: { notIn: ['WON', 'LOST', 'CANCELLED'] },
        },
      }),

      // Available agents
      db.user.count({
        where: {
          isAvailable: true,
          isActive: true,
          role: { in: ['AGENT', 'ADMIN', 'SUPERVISOR'] },
        },
      }),

      // Recent conversations for feed
      db.conversation.findMany({
        where: {
          status: { in: ['WAITING_ASSIGNMENT', 'AGENT_HANDLING', 'BOT_HANDLING'] },
        },
        include: {
          customer: {
            select: { id: true, name: true, phone: true },
          },
          agent: {
            select: { id: true, name: true },
          },
          messages: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
        orderBy: { lastMessageAt: 'desc' },
        take: 10,
      }),
    ]);

    // Agent-specific stats
    let myConversations = 0;
    let myPendingFollowUps = 0;

    if (session.user.role === 'AGENT') {
      [myConversations, myPendingFollowUps] = await Promise.all([
        db.conversation.count({
          where: {
            agentId: session.user.id,
            status: { in: ['AGENT_HANDLING', 'WAITING_CUSTOMER'] },
          },
        }),
        db.followUp.count({
          where: {
            agentId: session.user.id,
            isCompleted: false,
            dueDate: { lte: new Date(Date.now() + 24 * 60 * 60 * 1000) },
          },
        }),
      ]);
    }

    return NextResponse.json({
      success: true,
      data: {
        stats: {
          waitingCount,
          activeCount,
          resolvedToday,
          totalCustomers,
          activeDeals,
          availableAgents,
          myConversations,
          myPendingFollowUps,
        },
        recentConversations,
      },
    });

  } catch (error) {
    log.error('Dashboard stats error', { error });
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
