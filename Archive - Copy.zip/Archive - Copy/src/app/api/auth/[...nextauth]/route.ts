import NextAuth, { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import bcrypt from "bcrypt"
import { prisma } from "@/lib/prisma"

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text", placeholder: "admin@krearte.id" },
        password: { label: "Password", type: "password", placeholder: "••••••••" }
      },
      async authorize(credentials) {
        console.log("📧 Attempting login for:", credentials?.email)
        
        // Validasi input
        if (!credentials?.email || !credentials?.password) {
          console.log("❌ Email or password missing")
          return null
        }

        // Cari user di database
        const user = await prisma.user.findUnique({
          where: { email: credentials.email }
        })

        if (!user) {
          console.log("❌ User not found")
          return null
        }

        if (!user.passwordHash) {
          console.log("❌ User has no password set")
          return null
        }

        // Cek apakah user active
        if (!user.isActive) {
          console.log("❌ User account is not active")
          return null
        }

        // Verify password dengan bcrypt
        const isValid = await bcrypt.compare(credentials.password, user.passwordHash)
        
        if (!isValid) {
          console.log("❌ Invalid password")
          return null
        }

        console.log(`✅ Login successful for: ${user.email} (${user.role})`)
        
        // Return user object (tanpa password hash)
        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role, // UserRole enum: ADMIN | SUPERVISOR | AGENT | DESIGNER
          phone: user.phone || null,
          avatarUrl: user.avatarUrl || null,
          isAvailable: user.isAvailable,
          maxLoad: user.maxLoad,
          currentLoad: user.currentLoad,
        }
      }
    })
  ],
  
  // Callbacks untuk extend session & JWT
  callbacks: {
    async jwt({ token, user }) {
      // On sign in, add user properties to token
      if (user) {
        token.id = user.id
        token.role = user.role
        token.name = user.name
        token.email = user.email
        token.phone = user.phone
        token.avatarUrl = user.avatarUrl
        token.isAvailable = user.isAvailable
      }
      return token
    },
    
    async session({ session, token }) {
      // Add user properties to session
      if (session.user) {
        session.user.id = token.id as string
        session.user.role = token.role as string
        session.user.name = token.name as string
        session.user.email = token.email as string
        session.user.phone = token.phone as string | null
        session.user.avatarUrl = token.avatarUrl as string | null
        session.user.isAvailable = token.isAvailable as boolean
      }
      return session
    }
  },
  
  // Pages configuration
  pages: {
    signIn: "/login",
    signOut: "/login",
    error: "/login", // Error page
  },
  
  // Secret key
  secret: process.env.NEXTAUTH_SECRET,
  
  // Debug mode di development
  debug: process.env.NODE_ENV === "development",
  
  // Session configuration
  session: {
    strategy: "jwt", // Use JWT strategy
    maxAge: 30 * 24 * 60 * 60, // 30 days
    updateAge: 24 * 60 * 60, // 24 hours
  },
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }