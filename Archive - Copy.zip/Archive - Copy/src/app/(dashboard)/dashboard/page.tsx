'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  MessageSquare,
  Users,
  Clock,
  CheckCircle,
  Briefcase,
  UserCheck,
  ArrowRight,
} from 'lucide-react';
import Link from 'next/link';
import { getInitials, truncate } from '@/lib/utils';

interface DashboardStats {
  waitingCount: number;
  activeCount: number;
  resolvedToday: number;
  totalCustomers: number;
  activeDeals: number;
  availableAgents: number;
  myConversations: number;
  myPendingFollowUps: number;
}

interface RecentConversation {
  id: string;
  status: string;
  lastMessageAt: string;
  customer: {
    id: string;
    name: string | null;
    phone: string;
  };
  agent: {
    id: string;
    name: string;
  } | null;
  messages: Array<{
    content: string;
    createdAt: string;
  }>;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentConversations, setRecentConversations] = useState<RecentConversation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const res = await fetch('/api/dashboard');
      const data = await res.json();
      if (data.success) {
        setStats(data.data.stats);
        setRecentConversations(data.data.recentConversations);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Menunggu',
      value: stats?.waitingCount || 0,
      icon: Clock,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
    },
    {
      title: 'Aktif',
      value: stats?.activeCount || 0,
      icon: MessageSquare,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Selesai Hari Ini',
      value: stats?.resolvedToday || 0,
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      title: 'Total Pelanggan',
      value: stats?.totalCustomers || 0,
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
    },
    {
      title: 'Deal Aktif',
      value: stats?.activeDeals || 0,
      icon: Briefcase,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
    },
    {
      title: 'Agent Online',
      value: stats?.availableAgents || 0,
      icon: UserCheck,
      color: 'text-teal-600',
      bgColor: 'bg-teal-50',
    },
  ];

  const getStatusBadge = (status: string) => {
    const config: Record<string, { label: string; variant: 'default' | 'secondary' | 'warning' | 'success' }> = {
      WAITING_ASSIGNMENT: { label: 'Menunggu', variant: 'warning' },
      BOT_HANDLING: { label: 'Bot', variant: 'secondary' },
      AGENT_HANDLING: { label: 'Agent', variant: 'default' },
      WAITING_CUSTOMER: { label: 'Tunggu Reply', variant: 'secondary' },
    };
    const c = config[status] || { label: status, variant: 'secondary' };
    return <Badge variant={c.variant as any}>{c.label}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Selamat datang di Krearte Platform</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {statCards.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.title}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Percakapan Aktif</CardTitle>
          <Link href="/dashboard/conversations">
            <Button variant="ghost" size="sm">
              Lihat Semua <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {recentConversations.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Tidak ada percakapan aktif</p>
          ) : (
            <div className="space-y-3">
              {recentConversations.map((conv) => (
                <Link
                  key={conv.id}
                  href={`/dashboard/conversations/${conv.id}`}
                  className="flex items-center gap-4 p-3 rounded-lg hover:bg-muted transition-colors"
                >
                  <Avatar>
                    <AvatarFallback>{getInitials(conv.customer.name || conv.customer.phone)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium truncate">{conv.customer.name || conv.customer.phone}</p>
                      {getStatusBadge(conv.status)}
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      {conv.messages[0]?.content ? truncate(conv.messages[0].content, 50) : 'No messages'}
                    </p>
                  </div>
                  {conv.agent && (
                    <div className="text-xs text-muted-foreground">{conv.agent.name}</div>
                  )}
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
