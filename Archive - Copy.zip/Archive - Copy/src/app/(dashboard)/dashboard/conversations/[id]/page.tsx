'use client';

import { useEffect, useState, useRef } from 'react';
import { useParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Send,
  Phone,
  MapPin,
  Building,
  User,
  Clock,
  CheckCircle,
  ArrowLeft,
} from 'lucide-react';
import Link from 'next/link';
import { formatDate, getInitials, cn } from '@/lib/utils';

interface Message {
  id: string;
  content: string;
  contentType: string;
  senderType: 'CUSTOMER' | 'BOT' | 'AGENT' | 'SYSTEM';
  createdAt: string;
  waStatus: string;
  agent?: { id: string; name: string };
}

interface Conversation {
  id: string;
  status: string;
  priority: string;
  botCollectedData: any;
  startedAt: string;
  assignedAt: string;
  customer: {
    id: string;
    name: string | null;
    phone: string;
    email: string | null;
    category: string;
    companyName: string | null;
    city: string | null;
  };
  agent: { id: string; name: string; email: string } | null;
  messages: Message[];
}

export default function ConversationDetailPage() {
  const params = useParams();
  const id = params.id as string;
  
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [loading, setLoading] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchConversation();
  }, [id]);

  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages]);

  const fetchConversation = async () => {
    try {
      const res = await fetch(`/api/conversations/${id}`);
      const data = await res.json();
      if (data.success) {
        setConversation(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch:', error);
    } finally {
      setLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || sending) return;

    setSending(true);
    try {
      const res = await fetch(`/api/conversations/${id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: newMessage }),
      });
      const data = await res.json();
      if (data.success) {
        setNewMessage('');
        fetchConversation();
      }
    } catch (error) {
      console.error('Failed to send:', error);
    } finally {
      setSending(false);
    }
  };

  const handleTakeConversation = async () => {
    try {
      await fetch(`/api/conversations/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'take' }),
      });
      fetchConversation();
    } catch (error) {
      console.error('Failed to take:', error);
    }
  };

  const handleResolve = async () => {
    if (!confirm('Yakin ingin menyelesaikan percakapan ini?')) return;
    try {
      await fetch(`/api/conversations/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'resolve' }),
      });
      fetchConversation();
    } catch (error) {
      console.error('Failed to resolve:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!conversation) {
    return <div className="text-center py-8">Conversation not found</div>;
  }

  const { customer, messages, agent, status, botCollectedData } = conversation;

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4">
      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <Card className="mb-4">
          <CardContent className="py-3 px-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Link href="/dashboard/conversations">
                  <Button variant="ghost" size="icon">
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </Link>
                <Avatar>
                  <AvatarFallback>{getInitials(customer.name || customer.phone)}</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="font-semibold">{customer.name || customer.phone}</h2>
                  <p className="text-sm text-muted-foreground">{customer.phone}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {status === 'WAITING_ASSIGNMENT' && (
                  <Button onClick={handleTakeConversation} size="sm">
                    Ambil Chat
                  </Button>
                )}
                {['AGENT_HANDLING', 'WAITING_CUSTOMER'].includes(status) && (
                  <Button onClick={handleResolve} variant="outline" size="sm">
                    <CheckCircle className="h-4 w-4 mr-2" /> Selesai
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Messages */}
        <Card className="flex-1 flex flex-col overflow-hidden">
          <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={cn(
                  'flex',
                  msg.senderType === 'CUSTOMER' ? 'justify-start' : 'justify-end'
                )}
              >
                <div
                  className={cn(
                    'max-w-[70%] rounded-lg px-4 py-2 message-enter',
                    msg.senderType === 'CUSTOMER'
                      ? 'bg-muted'
                      : msg.senderType === 'BOT'
                      ? 'bg-blue-100 text-blue-900'
                      : 'bg-primary text-primary-foreground'
                  )}
                >
                  {msg.senderType !== 'CUSTOMER' && (
                    <p className="text-xs opacity-70 mb-1">
                      {msg.senderType === 'BOT' ? '🤖 Bot' : msg.agent?.name || 'Agent'}
                    </p>
                  )}
                  <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                  <p className="text-xs opacity-60 mt-1">
                    {formatDate(msg.createdAt)}
                    {msg.senderType !== 'CUSTOMER' && msg.waStatus && (
                      <span className="ml-2">
                        {msg.waStatus === 'READ' ? '✓✓' : msg.waStatus === 'DELIVERED' ? '✓✓' : '✓'}
                      </span>
                    )}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </CardContent>

          {/* Input */}
          {['AGENT_HANDLING', 'WAITING_CUSTOMER'].includes(status) && (
            <div className="border-t p-4">
              <form onSubmit={handleSendMessage} className="flex gap-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Ketik pesan..."
                  disabled={sending}
                  className="flex-1"
                />
                <Button type="submit" disabled={sending || !newMessage.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          )}

          {status === 'RESOLVED' && (
            <div className="border-t p-4 bg-green-50 text-center text-green-700">
              Percakapan sudah selesai
            </div>
          )}
        </Card>
      </div>

      {/* Sidebar - Customer Info */}
      <Card className="w-80 hidden lg:block">
        <CardHeader>
          <CardTitle className="text-lg">Info Pelanggan</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <Avatar className="h-16 w-16 mx-auto mb-2">
              <AvatarFallback className="text-xl">
                {getInitials(customer.name || customer.phone)}
              </AvatarFallback>
            </Avatar>
            <h3 className="font-semibold">{customer.name || 'Belum diketahui'}</h3>
            <Badge variant="secondary" className="mt-1">{customer.category}</Badge>
          </div>

          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <span>{customer.phone}</span>
            </div>
            {customer.email && (
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span>{customer.email}</span>
              </div>
            )}
            {customer.companyName && (
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-muted-foreground" />
                <span>{customer.companyName}</span>
              </div>
            )}
            {customer.city && (
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span>{customer.city}</span>
              </div>
            )}
          </div>

          {botCollectedData && Object.keys(botCollectedData).length > 0 && (
            <div className="pt-4 border-t">
              <h4 className="font-medium mb-2">Data dari Bot</h4>
              <div className="space-y-2 text-sm">
                {botCollectedData.needs && (
                  <div><span className="text-muted-foreground">Kebutuhan:</span> {botCollectedData.needs}</div>
                )}
                {botCollectedData.material && (
                  <div><span className="text-muted-foreground">Material:</span> {botCollectedData.material}</div>
                )}
                {botCollectedData.size && (
                  <div><span className="text-muted-foreground">Ukuran:</span> {botCollectedData.size}</div>
                )}
                {botCollectedData.budget && (
                  <div><span className="text-muted-foreground">Budget:</span> {botCollectedData.budget}</div>
                )}
              </div>
            </div>
          )}

          <div className="pt-4 border-t">
            <h4 className="font-medium mb-2">Status</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>Mulai: {formatDate(conversation.startedAt)}</span>
              </div>
              {agent && (
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span>Agent: {agent.name}</span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-4 border-t space-y-2">
            <Button variant="outline" className="w-full" asChild>
              <Link href={`/dashboard/customers/${customer.id}`}>Lihat Profil</Link>
            </Button>
            <Button variant="outline" className="w-full">Buat Deal</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
