import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

/**
 * GET /api/customers/[id]
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const customer = await prisma.customer.findUnique({
      where: { id: params.id },
      include: {
        conversations: {
          orderBy: { lastMessageAt: 'desc' }
        }
      }
    });

    if (!customer) {
      return NextResponse.json(
        { error: 'Customer not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: customer
    })

  } catch (error: any) {
    console.error('❌ Fetch customer error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/customers/[id]
 */
/**
 * PUT /api/customers/[id]
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { name, phone, email, category, companyName, city } = await request.json();

    // Validasi phone tidak boleh kosong
    if (!phone) {
      return NextResponse.json(
        { error: 'Phone is required' },
        { status: 400 }
      )
    }

    // Cek apakah phone sudah ada (kecuali phone lama dari customer ini)
    const existingCustomer = await prisma.customer.findFirst({
      where: {
        phone: phone,
        NOT: { id: params.id } // Exclude customer ini sendiri
      }
    });

    if (existingCustomer) {
      return NextResponse.json(
        { error: 'Customer with this phone number already exists' },
        { status: 400 }
      )
    }

    const customer = await prisma.customer.update({
      where: { id: params.id },
      data: {
        name,
        phone,
        email,
        category,
        companyName,
        city
      }
    });

    return NextResponse.json({
      success: true,
      message: 'Customer updated successfully',
      data: customer
    })

  } catch (error: any) {
    console.error('❌ Update customer error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/customers/[id]
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.customer.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      success: true,
      message: 'Customer deleted successfully'
    })

  } catch (error: any) {
    console.error('❌ Delete customer error:', error)
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    )
  }
}